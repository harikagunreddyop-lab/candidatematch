import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase-server';

export async function POST(req: NextRequest) {
  const supabase = createServiceClient();
  const body = await req.json();

  const { data, error } = await supabase
    .from('applications')
    .upsert({
      candidate_id: body.candidate_id,
      job_id: body.job_id,
      resume_version_id: body.resume_version_id || null,
      status: body.status || 'applied',
      applied_at: body.status === 'applied' ? new Date().toISOString() : null,
      notes: body.notes || null,
    }, { onConflict: 'candidate_id,job_id' })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json(data);
}

export async function PATCH(req: NextRequest) {
  const supabase = createServiceClient();
  const body = await req.json();

  const { data, error } = await supabase
    .from('applications')
    .update({
      status: body.status,
      notes: body.notes,
      ...(body.status === 'applied' ? { applied_at: new Date().toISOString() } : {}),
    })
    .eq('id', body.id)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json(data);
}
