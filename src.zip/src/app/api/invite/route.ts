// src/app/api/invite/route.ts
// Server-side invite — uses SUPABASE_SERVICE_ROLE_KEY so admin API is available
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (!authHeader) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { email, role, name } = await req.json();

  if (!email || !role) {
    return NextResponse.json({ error: 'email and role are required' }, { status: 400 });
  }
  if (!['candidate', 'recruiter', 'admin'].includes(role)) {
    return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
  }

  const adminClient = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  // Verify caller is admin
  const token = authHeader.replace('Bearer ', '');
  const { data: { user }, error: authErr } = await adminClient.auth.getUser(token);
  if (authErr || !user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: callerProfile } = await adminClient
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (callerProfile?.role !== 'admin') {
    return NextResponse.json({ error: 'Only admins can send invites' }, { status: 403 });
  }

  const displayName = name || email.split('@')[0];

  const redirectTo = role === 'candidate'
    ? `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard/candidate/onboarding`
    : `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard/recruiter`;

  // Send invite
  const { data: inviteData, error } = await adminClient.auth.admin.inviteUserByEmail(email, {
    redirectTo,
    data: { role, name: displayName },
  });

  if (error) {
    if (error.message?.includes('already been registered')) {
      return NextResponse.json({ error: 'This email is already registered in the system.' }, { status: 409 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // ── Immediately create profile + candidate rows server-side ──────────────
  // This ensures the candidate row exists even if the DB trigger is slow or
  // fails, so when the user logs in they won't see "account not linked".
  if (inviteData?.user?.id) {
    const newUserId = inviteData.user.id;

    // Upsert profile
    await adminClient.from('profiles').upsert({
      id: newUserId,
      email,
      name: displayName,
      role,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });

    // For candidates — also create their candidate row immediately
    if (role === 'candidate') {
      await adminClient.from('candidates').upsert({
        user_id: newUserId,
        email,
        full_name: displayName,
        primary_title: '',
        skills: [],
        secondary_titles: [],
        active: false,
        onboarding_completed: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' });
    }
  }

  return NextResponse.json({ success: true, email, role });
}