import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase-server';

const MAX_RESUMES_PER_CANDIDATE = 5;
const MAX_FILE_SIZE_MB = 10;

// ── GET — list resumes for a candidate ───────────────────────────────────────
export async function GET(req: NextRequest) {
  const candidateId = req.nextUrl.searchParams.get('candidate_id');
  if (!candidateId) return NextResponse.json({ error: 'candidate_id required' }, { status: 400 });

  const supabase = createServiceClient();
  const { data, error } = await supabase
    .from('candidate_resumes')
    .select('*')
    .eq('candidate_id', candidateId)
    .order('uploaded_at', { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ resumes: data || [] });
}

// ── POST — upload a new resume PDF ───────────────────────────────────────────
export async function POST(req: NextRequest) {
  const supabase = createServiceClient();

  const formData = await req.formData();
  const file = formData.get('file') as File | null;
  const candidateId = formData.get('candidate_id') as string | null;
  const label = (formData.get('label') as string) || 'Resume';

  if (!file || !candidateId) {
    return NextResponse.json({ error: 'file and candidate_id are required' }, { status: 400 });
  }

  if (file.type !== 'application/pdf') {
    return NextResponse.json({ error: 'Only PDF files are allowed' }, { status: 400 });
  }

  const fileSizeMB = file.size / (1024 * 1024);
  if (fileSizeMB > MAX_FILE_SIZE_MB) {
    return NextResponse.json({ error: `File too large. Max ${MAX_FILE_SIZE_MB}MB.` }, { status: 400 });
  }

  // Check current count
  const { count } = await supabase
    .from('candidate_resumes')
    .select('id', { count: 'exact', head: true })
    .eq('candidate_id', candidateId);

  if ((count || 0) >= MAX_RESUMES_PER_CANDIDATE) {
    return NextResponse.json(
      { error: `Maximum ${MAX_RESUMES_PER_CANDIDATE} resumes per candidate. Delete one first.` },
      { status: 400 }
    );
  }

  // Upload to Supabase Storage
  const fileName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `${candidateId}/${Date.now()}_${fileName}`;

  const arrayBuffer = await file.arrayBuffer();
  const { error: uploadError } = await supabase.storage
    .from('candidate-resumes')
    .upload(storagePath, arrayBuffer, {
      contentType: 'application/pdf',
      upsert: false,
    });

  if (uploadError) {
    return NextResponse.json({ error: 'Storage upload failed: ' + uploadError.message }, { status: 500 });
  }

  // Save record to DB
  const { data, error: dbError } = await supabase
    .from('candidate_resumes')
    .insert({
      candidate_id: candidateId,
      label,
      pdf_path: storagePath,
      file_name: file.name,
      file_size: file.size,
    })
    .select()
    .single();

  if (dbError) {
    // Clean up storage if DB insert failed
    await supabase.storage.from('candidate-resumes').remove([storagePath]);
    return NextResponse.json({ error: 'DB insert failed: ' + dbError.message }, { status: 500 });
  }

  return NextResponse.json({ resume: data });
}

// ── DELETE — remove a resume ──────────────────────────────────────────────────
export async function DELETE(req: NextRequest) {
  const supabase = createServiceClient();
  const { resume_id } = await req.json();
  if (!resume_id) return NextResponse.json({ error: 'resume_id required' }, { status: 400 });

  // Get the record first so we can delete from storage too
  const { data: resume, error: fetchError } = await supabase
    .from('candidate_resumes')
    .select('pdf_path')
    .eq('id', resume_id)
    .single();

  if (fetchError || !resume) {
    return NextResponse.json({ error: 'Resume not found' }, { status: 404 });
  }

  // Delete from storage
  await supabase.storage.from('candidate-resumes').remove([resume.pdf_path]);

  // Delete from DB
  const { error } = await supabase
    .from('candidate_resumes')
    .delete()
    .eq('id', resume_id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ success: true });
}