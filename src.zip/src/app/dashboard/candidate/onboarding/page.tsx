'use client';
// src/app/dashboard/candidate/onboarding/page.tsx
// FIXED VERSION - Properly sets flags and waits for admin approval
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';
import { Spinner } from '@/components/ui';
import { CheckCircle2, ArrowRight, ArrowLeft, X, Plus, Sparkles } from 'lucide-react';
import { cn } from '@/utils/helpers';

const VISA_OPTIONS = ['US Citizen','Green Card','H1B','H4 EAD','L2 EAD','OPT','CPT','TN Visa','O1','Requires Sponsorship','Other'];
const AVAILABILITY_OPTIONS = ['Immediately','2 Weeks','1 Month','3 Months','Not Looking'];
const COMMON_SKILLS = ['Python','JavaScript','TypeScript','React','Node.js','Java','SQL','AWS','Docker','Kubernetes','Git','PostgreSQL','MongoDB','Redis','GraphQL','REST APIs','CI/CD','Linux','Excel','Tableau','Power BI','Salesforce','Figma','Machine Learning','Data Analysis','Project Management','Agile/Scrum','Communication','Leadership'];

function TagInput({ value, onChange, placeholder, suggestions }: {
  value: string[]; onChange: (v: string[]) => void; placeholder?: string; suggestions?: string[];
}) {
  const [input, setInput] = useState('');
  const uid = 'ti-' + (placeholder||'').replace(/\s/g,'');
  const add = (tag?: string) => {
    const t = (tag || input).trim();
    if (t && !value.includes(t)) onChange([...value, t]);
    if (!tag) setInput('');
  };
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5 p-2.5 border border-surface-200 rounded-xl min-h-[44px] cursor-text focus-within:border-brand-400 focus-within:ring-2 focus-within:ring-brand-100 transition-all"
        onClick={() => document.getElementById(uid)?.focus()}>
        {value.map((tag, i) => (
          <span key={i} className="flex items-center gap-1 px-2.5 py-1 bg-brand-100 text-brand-700 rounded-lg text-xs font-medium">
            {tag}
            <button type="button" onClick={e => { e.stopPropagation(); onChange(value.filter((_,j) => j !== i)); }}><X size={10}/></button>
          </span>
        ))}
        <input id={uid} value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key==='Enter'||e.key===','){e.preventDefault();add();} }}
          onBlur={() => add()} placeholder={value.length===0 ? placeholder : ''}
          className="flex-1 min-w-[120px] outline-none text-sm bg-transparent placeholder-surface-400" />
      </div>
      {suggestions && (
        <div className="flex flex-wrap gap-1.5">
          {suggestions.filter(s => !value.includes(s)).slice(0, 12).map(s => (
            <button key={s} type="button" onClick={() => add(s)}
              className="px-2 py-0.5 rounded-lg border border-surface-200 text-xs text-surface-600 hover:border-brand-300 hover:text-brand-700 hover:bg-brand-50 transition-colors">
              + {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const STEPS = [
  { id: 'welcome',     label: 'Welcome',     description: 'Get started' },
  { id: 'basic',       label: 'About You',   description: 'Name & contact' },
  { id: 'skills',      label: 'Skills',      description: 'What you know' },
  { id: 'experience',  label: 'Experience',  description: 'Your background' },
  { id: 'preferences', label: 'Preferences', description: 'What you want' },
  { id: 'done',        label: 'Done',        description: 'All set!' },
];

export default function CandidateOnboarding() {
  const router = useRouter();
  const supabase = createClient();
  const [step, setStep] = useState(0);
  const [candidateId, setCandidateId] = useState<string|null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string|null>(null);
  const [userName, setUserName] = useState('');

  const [form, setForm] = useState({
    full_name: '', primary_title: '', location: '',
    phone: '', linkedin_url: '', visa_status: '',
    summary: '',
    skills: [] as string[],
    soft_skills: [] as string[],
    years_of_experience: '',
    current_company: '', current_title: '', current_start: '',
    availability: '', salary_min: '', salary_max: '',
    open_to_remote: true, open_to_relocation: false,
    target_roles: [] as string[], target_locations: [] as string[],
  });

  const set = (k: string, v: any) => setForm(p => ({...p, [k]: v}));

  useEffect(() => {
    async function init() {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) { router.push('/'); return; }

      // Get their candidate row (created by the trigger on signup)
      const { data: cand } = await supabase
        .from('candidates')
        .select('id, full_name, onboarding_completed')
        .eq('user_id', user.id)
        .single();

      if (!cand) {
        // Trigger didn't fire or race condition — create it now
        const { data: newCand } = await supabase
          .from('candidates')
          .insert({
            user_id: user.id,
            full_name: user.user_metadata?.name || user.email?.split('@')[0] || '',
            email: user.email,
            primary_title: '',
            skills: [],
            secondary_titles: [],
            active: false,
            onboarding_completed: false,
            approval_status: 'pending',
          })
          .select('id, full_name')
          .single();
        if (newCand) {
          setCandidateId(newCand.id);
          setUserName(newCand.full_name || '');
          setForm(p => ({...p, full_name: newCand.full_name || ''}));
        }
      } else {
        // If already completed onboarding, skip to dashboard
        if (cand.onboarding_completed) {
          router.push('/dashboard/candidate');
          return;
        }
        setCandidateId(cand.id);
        setUserName(cand.full_name || '');
        setForm(p => ({...p, full_name: cand.full_name || ''}));
      }
    }
    init();
  }, []);

  const saveAndNext = async () => {
    if (!candidateId) return;
    setSaving(true); setError(null);

    const isLastDataStep = step === 4; // preferences step

    // Build experience array from the simple fields
    const experience = form.current_company ? [{
      company: form.current_company,
      title: form.current_title || form.primary_title,
      start_date: form.current_start || '',
      end_date: '',
      current: true,
      responsibilities: [],
    }] : [];

    const payload: any = {
      full_name: form.full_name,
      primary_title: form.primary_title,
      location: form.location || null,
      phone: form.phone || null,
      linkedin_url: form.linkedin_url || null,
      visa_status: form.visa_status || null,
      summary: form.summary || null,
      skills: form.skills,
      soft_skills: form.soft_skills,
      years_of_experience: form.years_of_experience ? parseInt(form.years_of_experience) : null,
      experience,
      availability: form.availability || null,
      salary_min: form.salary_min ? parseInt(form.salary_min) : null,
      salary_max: form.salary_max ? parseInt(form.salary_max) : null,
      open_to_remote: form.open_to_remote,
      open_to_relocation: form.open_to_relocation,
      target_roles: form.target_roles,
      target_locations: form.target_locations,
    };

    // ✅ FIX: When completing onboarding, set proper flags
    if (isLastDataStep) {
      payload.onboarding_completed = true;
      payload.approval_status = 'pending';  // Explicitly set
      payload.active = false;  // ✅ FIXED: Stay inactive until admin approves
    }

    const { error: err } = await supabase
      .from('candidates')
      .update(payload)
      .eq('id', candidateId);

    if (err) { setError(err.message); setSaving(false); return; }

    setSaving(false);
    if (isLastDataStep) {
      setStep(5); // done screen
    } else {
      setStep(s => s + 1);
    }
  };

  const [redirecting, setRedirecting] = useState(false);

  const goToDashboard = async () => {
    setRedirecting(true);
    // Don't change any flags here - they're already set correctly
    await new Promise(r => setTimeout(r, 400));
    router.replace('/dashboard/candidate');
  };

  const currentStep = STEPS[step];
  const progress = (step / (STEPS.length - 1)) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Progress bar */}
        {step > 0 && step < 5 && (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <p className="text-xs text-surface-500">Step {step} of {STEPS.length - 2}</p>
              <p className="text-xs text-surface-500">{Math.round(progress)}% complete</p>
            </div>
            <div className="w-full bg-surface-200 rounded-full h-1.5">
              <div className="bg-brand-500 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }} />
            </div>
            <div className="flex justify-between mt-2">
              {STEPS.slice(1, -1).map((s, i) => (
                <span key={s.id} className={cn('text-[10px]', step > i ? 'text-brand-600 font-medium' : 'text-surface-400')}>
                  {s.label}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-xl p-8">

          {/* ── Welcome ── */}
          {step === 0 && (
            <div className="text-center space-y-6">
              <div className="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center mx-auto">
                <Sparkles size={28} className="text-brand-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-surface-900">
                  Welcome{userName ? `, ${userName.split(' ')[0]}` : ''}! 👋
                </h1>
                <p className="text-surface-500 mt-2 text-sm leading-relaxed">
                  Let's set up your profile in just a few minutes. Your recruiter will use this to match you with the best job opportunities.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 text-left">
                {[
                  ['🎯', 'Smart Matching', 'AI matches you to roles based on your skills'],
                  ['📄', 'Custom Resumes', 'Auto-generated resume for each application'],
                  ['📊', 'Track Progress', 'See every application status in real-time'],
                  ['🔒', 'Private & Secure', 'Only your recruiter can see your profile'],
                ].map(([icon, title, desc]) => (
                  <div key={title as string} className="p-3 bg-surface-50 rounded-xl">
                    <p className="text-lg mb-1">{icon}</p>
                    <p className="text-xs font-semibold text-surface-800">{title}</p>
                    <p className="text-[11px] text-surface-500 mt-0.5">{desc}</p>
                  </div>
                ))}
              </div>
              <button onClick={() => setStep(1)} className="btn-primary w-full flex items-center justify-center gap-2">
                Get Started <ArrowRight size={16}/>
              </button>
            </div>
          )}

          {/* ── Basic Info ── */}
          {step === 1 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-surface-900">About You</h2>
                <p className="text-sm text-surface-500 mt-1">Basic information your recruiter needs</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="label">Full Name <span className="text-red-500">*</span></label>
                  <input value={form.full_name} onChange={e => set('full_name', e.target.value)}
                    className="input" placeholder="Jane Smith" />
                </div>
                <div>
                  <label className="label">Current / Target Job Title <span className="text-red-500">*</span></label>
                  <input value={form.primary_title} onChange={e => set('primary_title', e.target.value)}
                    className="input" placeholder="Software Engineer" />
                </div>
                <div>
                  <label className="label">Location</label>
                  <input value={form.location} onChange={e => set('location', e.target.value)}
                    className="input" placeholder="New York, NY" />
                </div>
                <div>
                  <label className="label">Phone</label>
                  <input value={form.phone} onChange={e => set('phone', e.target.value)}
                    className="input" type="tel" placeholder="+1 555-0123" />
                </div>
                <div>
                  <label className="label">LinkedIn URL</label>
                  <input value={form.linkedin_url} onChange={e => set('linkedin_url', e.target.value)}
                    className="input" type="url" placeholder="https://linkedin.com/in/..." />
                </div>
                <div>
                  <label className="label">Work Authorization</label>
                  <select value={form.visa_status} onChange={e => set('visa_status', e.target.value)}
                    className="input" title="Visa status" aria-label="Visa status">
                    <option value="">— Select —</option>
                    {VISA_OPTIONS.map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Professional Summary <span className="text-surface-400 text-xs font-normal">optional</span></label>
                  <textarea value={form.summary} onChange={e => set('summary', e.target.value)}
                    className="input h-24 resize-none" placeholder="Brief overview of your background and goals..." />
                </div>
              </div>
            </div>
          )}

          {/* ── Skills ── */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-surface-900">Your Skills</h2>
                <p className="text-sm text-surface-500 mt-1">These are used by AI to match you with jobs — be thorough</p>
              </div>
              <div>
                <label className="label">Technical Skills <span className="text-red-500">*</span></label>
                <p className="text-xs text-surface-400 mb-2">Type and press Enter, or click suggestions below</p>
                <TagInput value={form.skills} onChange={v => set('skills', v)}
                  placeholder="Python, React, SQL..." suggestions={COMMON_SKILLS} />
              </div>
              <div>
                <label className="label">Years of Experience</label>
                <input value={form.years_of_experience} onChange={e => set('years_of_experience', e.target.value)}
                  className="input w-32" type="number" min="0" max="50" placeholder="5" />
              </div>
              <div>
                <label className="label">Soft Skills <span className="text-surface-400 text-xs font-normal">optional</span></label>
                <TagInput value={form.soft_skills} onChange={v => set('soft_skills', v)}
                  placeholder="Leadership, Communication..."
                  suggestions={['Leadership','Communication','Teamwork','Problem Solving','Agile','Scrum','Mentoring','Stakeholder Management']} />
              </div>
            </div>
          )}

          {/* ── Experience ── */}
          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-surface-900">Experience</h2>
                <p className="text-sm text-surface-500 mt-1">Tell us where you work now (your recruiter will help fill in the full history)</p>
              </div>
              <div className="p-4 bg-surface-50 rounded-xl border border-surface-200 space-y-4">
                <p className="text-xs font-semibold text-surface-700 uppercase tracking-wide">Current / Most Recent Role</p>
                <div>
                  <label className="label">Company</label>
                  <input value={form.current_company} onChange={e => set('current_company', e.target.value)}
                    className="input" placeholder="Acme Corp" />
                </div>
                <div>
                  <label className="label">Your Title There</label>
                  <input value={form.current_title} onChange={e => set('current_title', e.target.value)}
                    className="input" placeholder="Senior Engineer" />
                </div>
                <div>
                  <label className="label">Start Date</label>
                  <input value={form.current_start} onChange={e => set('current_start', e.target.value)}
                    className="input" type="month" />
                </div>
              </div>
              <p className="text-xs text-surface-400 bg-brand-50 border border-brand-100 rounded-lg px-3 py-2">
                💡 Your recruiter will complete your full work history and education after your first call.
              </p>
            </div>
          )}

          {/* ── Preferences ── */}
          {step === 4 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-surface-900">Job Preferences</h2>
                <p className="text-sm text-surface-500 mt-1">Helps us find the right opportunities for you</p>
              </div>
              <div>
                <label className="label">Availability</label>
                <select value={form.availability} onChange={e => set('availability', e.target.value)}
                  className="input" title="Availability" aria-label="Availability">
                  <option value="">— When can you start? —</option>
                  {AVAILABILITY_OPTIONS.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Salary Min (USD/yr)</label>
                  <input value={form.salary_min} onChange={e => set('salary_min', e.target.value)}
                    className="input" type="number" placeholder="80000" />
                </div>
                <div>
                  <label className="label">Salary Max (USD/yr)</label>
                  <input value={form.salary_max} onChange={e => set('salary_max', e.target.value)}
                    className="input" type="number" placeholder="120000" />
                </div>
              </div>
              <div className="flex gap-6">
                {[['open_to_remote','Open to remote'],['open_to_relocation','Open to relocation']].map(([key, label]) => (
                  <label key={key} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={(form as any)[key]} onChange={e => set(key, e.target.checked)}
                      className="rounded border-surface-300 text-brand-600 w-4 h-4" />
                    <span className="text-sm text-surface-700">{label}</span>
                  </label>
                ))}
              </div>
              <div>
                <label className="label">Target Roles <span className="text-surface-400 text-xs font-normal">optional</span></label>
                <TagInput value={form.target_roles} onChange={v => set('target_roles', v)}
                  placeholder="Senior Engineer, Tech Lead..." />
              </div>
              <div>
                <label className="label">Preferred Locations <span className="text-surface-400 text-xs font-normal">optional</span></label>
                <TagInput value={form.target_locations} onChange={v => set('target_locations', v)}
                  placeholder="New York, Austin, Remote..." />
              </div>
            </div>
          )}

          {/* ── Done ── */}
          {step === 5 && (
            <div className="text-center space-y-6 py-4">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto">
                <CheckCircle2 size={28} className="text-green-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-surface-900">Profile submitted! 🎉</h2>
                <p className="text-surface-500 mt-2 text-sm leading-relaxed">
                  Your profile is now under review by our team. We'll notify you once it's approved and a recruiter is assigned.
                </p>
              </div>
              <div className="bg-brand-50 border border-brand-200 rounded-xl p-4 text-left space-y-2">
                <p className="text-xs font-semibold text-brand-800">⏳ What happens next:</p>
                {[
                  'Our admin reviews your profile (typically within 1 business day)',
                  'Your profile is approved and activated in the system',
                  'A recruiter is assigned to work with you',
                  'Your dashboard unlocks with matched jobs and applications',
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-brand-600 font-bold text-xs mt-0.5">{i+1}.</span>
                    <p className="text-xs text-brand-700">{item}</p>
                  </div>
                ))}
              </div>
              <button onClick={goToDashboard} disabled={redirecting}
                className="btn-primary text-sm min-w-[200px] flex items-center justify-center gap-2 mx-auto">
                {redirecting ? <Spinner size={14} /> : 'Continue to Dashboard'}
              </button>
              <p className="text-xs text-surface-400">
                You'll receive an email when your profile is approved and a recruiter is assigned.
              </p>
            </div>
          )}

          {/* Navigation buttons */}
          {step > 0 && step < 5 && (
            <div className="mt-6 pt-5 border-t border-surface-100 flex items-center justify-between">
              <button onClick={() => setStep(s => s - 1)} disabled={saving}
                className="btn-ghost text-sm flex items-center gap-1.5">
                <ArrowLeft size={14}/> Back
              </button>

              {error && <p className="text-xs text-red-600 flex-1 mx-4">{error}</p>}

              <button
                onClick={saveAndNext}
                disabled={saving || !form.full_name || !form.primary_title || (step === 2 && form.skills.length === 0)}
                className="btn-primary text-sm min-w-[120px] flex items-center justify-center gap-2">
                {saving ? <Spinner size={14}/> : null}
                {step === 4 ? 'Complete Setup' : 'Continue'}
                {!saving && <ArrowRight size={14}/>}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}