'use client';
import { useState, useEffect, useRef } from 'react';
import { createClient } from '@/lib/supabase-browser';
import { EmptyState, Spinner, StatusBadge } from '@/components/ui';
import {
  ClipboardList, Briefcase, FileText, User, Upload, Download,
  Trash2, AlertCircle, Plus, ExternalLink, ChevronRight,
  TrendingUp, Target, Star, CheckCircle2, X, MapPin,
  Linkedin, Phone, Mail, RefreshCw,
} from 'lucide-react';
import { formatDate, formatRelative, cn } from '@/utils/helpers';

interface CandidateResume {
  id: string;
  label: string;
  pdf_path: string;
  file_name: string;
  file_size: number;
  uploaded_at: string;
}

const MAX_RESUMES = 5;

function formatBytes(bytes: number): string {
  if (!bytes) return '';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function ATSScoreBadge({ score, decision }: { score: number; decision?: string }) {
  const color = score >= 80
    ? 'bg-green-100 text-green-700 border-green-200'
    : score >= 65
    ? 'bg-yellow-100 text-yellow-700 border-yellow-200'
    : 'bg-red-100 text-red-700 border-red-200';
  const label = decision || (score >= 80 ? 'Interview Possible' : score >= 65 ? 'Borderline' : 'Auto-Reject');
  return (
    <div className={cn('flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold shrink-0', color)}>
      <span className="text-base font-bold">{score}</span>
      <span className="font-medium">{label}</span>
    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string; value: any; icon: React.ReactNode; color: string }) {
  return (
    <div className="card p-4 flex items-center gap-4">
      <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', color)}>{icon}</div>
      <div>
        <p className="text-xl font-bold text-surface-900">{value}</p>
        <p className="text-xs text-surface-500">{label}</p>
      </div>
    </div>
  );
}

function parseMatchReason(reason: string) {
  const parts = (reason || '').split('|').map(s => s.trim());
  return {
    strength: parts.find(p => p.startsWith('[STRENGTH]'))?.replace('[STRENGTH]', '').trim() || '',
    gap: parts.find(p => p.startsWith('[GAP]'))?.replace('[GAP]', '').trim() || '',
    risk: parts.find(p => p.startsWith('[RISK]'))?.replace('[RISK]', '').trim() || '',
    resume: parts.find(p => p.startsWith('[RESUME]'))?.replace('[RESUME]', '').trim() || '',
  };
}

export default function CandidateDashboard() {
  const supabase = createClient();
  const [candidate, setCandidate] = useState<any>(null);
  const [matches, setMatches] = useState<any[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [uploadedResumes, setUploadedResumes] = useState<CandidateResume[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'overview' | 'matches' | 'applications' | 'resumes' | 'profile'>('overview');
  const [notLinked, setNotLinked] = useState(false);

  // Resume upload
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadLabel, setUploadLabel] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [deletingResume, setDeletingResume] = useState<CandidateResume | null>(null);
  const [deleting, setDeleting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // Apply
  const [applying, setApplying] = useState<string | null>(null);

  // Profile edit
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState<any>({});
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setLoading(false); return; }

    const { data: cand } = await supabase
      .from('candidates').select('*').eq('user_id', session.user.id).single();

    if (!cand) { setNotLinked(true); setLoading(false); return; }
    setCandidate(cand);
    setProfileForm({
      full_name: cand.full_name || '',
      phone: cand.phone || '',
      location: cand.location || '',
      linkedin_url: cand.linkedin_url || '',
      portfolio_url: cand.portfolio_url || '',
      summary: cand.summary || '',
    });

    const [mch, apps, resumes] = await Promise.all([
      supabase.from('candidate_job_matches')
        .select('*, job:jobs(id, title, company, location, url, remote_type, job_type, salary_min, salary_max)')
        .eq('candidate_id', cand.id)
        .order('fit_score', { ascending: false })
        .limit(50),
      supabase.from('applications')
        .select('*, job:jobs(title, company, location, url)')
        .eq('candidate_id', cand.id)
        .order('created_at', { ascending: false }),
      fetch(`/api/candidate-resumes?candidate_id=${cand.id}`).then(r => r.json()),
    ]);

    setMatches(mch.data || []);
    setApplications(apps.data || []);
    setUploadedResumes(resumes.resumes || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const applyToJob = async (jobId: string) => {
    if (!candidate) return;
    setApplying(jobId);
    await supabase.from('applications').upsert({
      candidate_id: candidate.id,
      job_id: jobId,
      status: 'applied',
      applied_at: new Date().toISOString(),
    }, { onConflict: 'candidate_id,job_id' });
    await load();
    setApplying(null);
  };

  const handleUpload = async (file: File) => {
    setUploadError(null);
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('candidate_id', candidate.id);
    formData.append('label', uploadLabel.trim() || file.name.replace('.pdf', ''));
    try {
      const res = await fetch('/api/candidate-resumes', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      setShowUploadModal(false);
      setUploadLabel('');
      await load();
    } catch (e: any) {
      setUploadError(e.message);
    }
    setUploading(false);
  };

  const handleDeleteResume = async () => {
    if (!deletingResume) return;
    setDeleting(true);
    const res = await fetch('/api/candidate-resumes', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resume_id: deletingResume.id }),
    });
    if (res.ok) { setDeletingResume(null); await load(); }
    setDeleting(false);
  };

  const downloadResume = async (pdfPath: string) => {
    const { data } = await supabase.storage.from('resumes').createSignedUrl(pdfPath, 300);
    if (data?.signedUrl) window.open(data.signedUrl, '_blank');
  };

  const saveProfile = async () => {
    setSavingProfile(true);
    setProfileError(null);
    const { error } = await supabase.from('candidates').update({
      full_name: profileForm.full_name,
      phone: profileForm.phone || null,
      location: profileForm.location || null,
      linkedin_url: profileForm.linkedin_url || null,
      portfolio_url: profileForm.portfolio_url || null,
      summary: profileForm.summary || null,
    }).eq('id', candidate.id);
    if (error) setProfileError(error.message);
    else { setEditingProfile(false); await load(); }
    setSavingProfile(false);
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>;

  if (notLinked) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
      <div className="w-16 h-16 rounded-full bg-surface-100 flex items-center justify-center">
        <User size={28} className="text-surface-400" />
      </div>
      <h2 className="text-lg font-semibold text-surface-900">Profile not linked</h2>
      <p className="text-sm text-surface-500 max-w-sm">Your account hasn't been linked to a candidate profile yet. Please contact your recruiter.</p>
    </div>
  );

  const topScore = matches[0]?.fit_score || 0;
  const avgScore = matches.length > 0 ? Math.round(matches.reduce((s, m) => s + m.fit_score, 0) / matches.length) : 0;
  const interviewPossible = matches.filter(m => m.fit_score >= 80).length;
  const alreadyApplied = new Set(applications.map(a => a.job_id));

  const TABS = [
    { key: 'overview' as const, label: 'Overview', icon: <TrendingUp size={14} /> },
    { key: 'matches' as const, label: 'Matched Jobs', icon: <Target size={14} />, count: matches.length },
    { key: 'applications' as const, label: 'Applications', icon: <ClipboardList size={14} />, count: applications.length },
    { key: 'resumes' as const, label: 'My Resumes', icon: <FileText size={14} />, count: uploadedResumes.length },
    { key: 'profile' as const, label: 'My Profile', icon: <User size={14} /> },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 font-display">
            Welcome back, {candidate.full_name?.split(' ')[0]} 👋
          </h1>
          <p className="text-sm text-surface-500 mt-1">
            {candidate.primary_title}{candidate.location ? ` · ${candidate.location}` : ''}
          </p>
        </div>
        <button onClick={load} className="btn-ghost text-sm flex items-center gap-1.5 text-surface-400">
          <RefreshCw size={14} /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-surface-200 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={cn(
              'flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors',
              tab === t.key ? 'border-brand-600 text-brand-700' : 'border-transparent text-surface-500 hover:text-surface-700'
            )}>
            {t.icon}
            {t.label}
            {'count' in t && t.count !== undefined && t.count > 0 && (
              <span className={cn('px-1.5 py-0.5 rounded-full text-[10px] font-bold',
                tab === t.key ? 'bg-brand-100 text-brand-700' : 'bg-surface-100 text-surface-500')}>
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ── OVERVIEW ── */}
      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Matched Jobs" value={matches.length} icon={<Briefcase size={18} className="text-brand-600" />} color="bg-brand-50" />
            <StatCard label="Applications" value={applications.length} icon={<ClipboardList size={18} className="text-purple-600" />} color="bg-purple-50" />
            <StatCard label="Interview Possible" value={interviewPossible} icon={<Star size={18} className="text-green-600" />} color="bg-green-50" />
            <StatCard label="Avg ATS Score" value={avgScore || '—'} icon={<TrendingUp size={18} className="text-amber-600" />} color="bg-amber-50" />
          </div>

          {/* ATS score chart */}
          {matches.length > 0 && (
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Your ATS Score Distribution</h3>
              <div className="flex items-end gap-1 h-16 mb-3">
                {[
                  { from: 0, to: 40 }, { from: 40, to: 50 }, { from: 50, to: 60 },
                  { from: 60, to: 70 }, { from: 70, to: 80 }, { from: 80, to: 90 }, { from: 90, to: 101 }
                ].map(({ from, to }, i) => {
                  const count = matches.filter(m => m.fit_score >= from && m.fit_score < to).length;
                  const max = Math.max(1, ...([0,40,50,60,70,80,90].map((f, j, arr) =>
                    matches.filter(m => m.fit_score >= f && m.fit_score < (arr[j+1] || 101)).length
                  )));
                  const height = Math.max(4, (count / max) * 56);
                  const color = to > 80 ? 'bg-green-400' : to > 65 ? 'bg-yellow-400' : 'bg-red-300';
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-[10px] text-surface-400">{count || ''}</span>
                      <div className={cn('w-full rounded-t', color)} style={{ height }} />
                      <span className="text-[9px] text-surface-400">{from}+</span>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-4 text-xs flex-wrap">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-400 inline-block" />Interview Possible (80+)</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400 inline-block" />Borderline (65–79)</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-300 inline-block" />Auto-Reject (&lt;65)</span>
              </div>
            </div>
          )}

          {/* Top matches preview */}
          {matches.length > 0 && (
            <div className="card">
              <div className="px-5 py-4 border-b border-surface-100 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-surface-800">Top Matches</h3>
                <button onClick={() => setTab('matches')} className="text-xs text-brand-600 hover:underline flex items-center gap-1">
                  View all <ChevronRight size={12} />
                </button>
              </div>
              <div className="divide-y divide-surface-50">
                {matches.slice(0, 5).map(m => {
                  const reason = parseMatchReason(m.match_reason);
                  const applied = alreadyApplied.has(m.job_id);
                  return (
                    <div key={m.id} className="px-5 py-3 flex items-center gap-4">
                      <ATSScoreBadge score={m.fit_score} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-surface-900 truncate">{m.job?.title}</p>
                        <p className="text-xs text-surface-500 truncate">{m.job?.company} · {m.job?.location || 'Location not listed'}</p>
                        {reason.strength && <p className="text-xs text-green-600 mt-0.5 truncate">✓ {reason.strength}</p>}
                      </div>
                      {applied
                        ? <span className="text-xs text-green-600 font-medium flex items-center gap-1 shrink-0"><CheckCircle2 size={12} />Applied</span>
                        : <button onClick={() => applyToJob(m.job_id)} disabled={applying === m.job_id}
                            className="btn-primary text-xs py-1.5 px-3 shrink-0 flex items-center gap-1">
                            {applying === m.job_id ? <Spinner size={12} /> : 'Apply'}
                          </button>
                      }
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Recent applications */}
          {applications.length > 0 && (
            <div className="card">
              <div className="px-5 py-4 border-b border-surface-100 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-surface-800">Recent Applications</h3>
                <button onClick={() => setTab('applications')} className="text-xs text-brand-600 hover:underline flex items-center gap-1">
                  View all <ChevronRight size={12} />
                </button>
              </div>
              <div className="divide-y divide-surface-50">
                {applications.slice(0, 4).map(a => (
                  <div key={a.id} className="px-5 py-3 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-surface-900 truncate">{a.job?.title}</p>
                      <p className="text-xs text-surface-500">{a.job?.company}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <StatusBadge status={a.status} />
                      <span className="text-xs text-surface-400">{formatRelative(a.created_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload nudge if no resumes */}
          {uploadedResumes.length === 0 && (
            <div className="card p-5 border-amber-200 bg-amber-50 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
                <Upload size={18} className="text-amber-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-amber-800">Upload your resume to improve ATS scores</p>
                <p className="text-xs text-amber-700 mt-1">
                  Our AI reads your full resume to score matches more accurately. Without it, scoring uses only your profile fields.
                </p>
                <button onClick={() => setTab('resumes')} className="mt-3 btn-primary text-xs py-1.5 px-3">
                  Upload Resume →
                </button>
              </div>
            </div>
          )}

          {matches.length === 0 && applications.length === 0 && (
            <EmptyState icon={<Target size={24} />} title="No matches yet"
              description="Your recruiter is working on finding the best jobs for you. Check back soon!" />
          )}
        </div>
      )}

      {/* ── MATCHES ── */}
      {tab === 'matches' && (
        <div className="space-y-3">
          {matches.length === 0 ? (
            <EmptyState icon={<Briefcase size={24} />} title="No matches yet"
              description="Your recruiter hasn't run matching yet. Check back soon!" />
          ) : matches.map(m => {
            const reason = parseMatchReason(m.match_reason);
            const applied = alreadyApplied.has(m.job_id);
            const appStatus = applications.find(a => a.job_id === m.job_id)?.status;
            return (
              <div key={m.id} className="card p-4 space-y-3">
                <div className="flex items-start gap-4 flex-wrap">
                  <ATSScoreBadge score={m.fit_score} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <p className="font-semibold text-surface-900">{m.job?.title}</p>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap text-xs text-surface-500">
                          <span>{m.job?.company}</span>
                          {m.job?.location && <span className="flex items-center gap-0.5"><MapPin size={10} />{m.job.location}</span>}
                          {m.job?.remote_type && <span className="capitalize">{m.job.remote_type}</span>}
                          {m.job?.salary_min && (
                            <span>${Math.round(m.job.salary_min / 1000)}k{m.job.salary_max ? `–$${Math.round(m.job.salary_max / 1000)}k` : '+'}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {m.job?.url && (
                          <a href={m.job.url} target="_blank" rel="noreferrer" className="btn-ghost p-1.5" title="View posting">
                            <ExternalLink size={13} />
                          </a>
                        )}
                        {applied
                          ? <span className="flex items-center gap-1 text-xs text-green-600 font-medium px-2 py-1 bg-green-50 rounded-lg">
                              <CheckCircle2 size={12} /> {appStatus || 'Applied'}
                            </span>
                          : <button onClick={() => applyToJob(m.job_id)} disabled={applying === m.job_id}
                              className="btn-primary text-xs py-1.5 px-3 flex items-center gap-1">
                              {applying === m.job_id ? <Spinner size={12} /> : 'Apply Now'}
                            </button>
                        }
                      </div>
                    </div>
                  </div>
                </div>

                {/* ATS breakdown */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-surface-50">
                  {reason.strength && (
                    <div className="flex items-start gap-1.5 text-xs">
                      <span className="text-green-500 mt-0.5 shrink-0">✓</span>
                      <span className="text-surface-600"><span className="font-medium text-green-700">Strength: </span>{reason.strength}</span>
                    </div>
                  )}
                  {reason.gap && (
                    <div className="flex items-start gap-1.5 text-xs">
                      <span className="text-amber-500 mt-0.5 shrink-0">△</span>
                      <span className="text-surface-600"><span className="font-medium text-amber-700">Gap: </span>{reason.gap}</span>
                    </div>
                  )}
                  {reason.risk && reason.risk !== 'None' && (
                    <div className="flex items-start gap-1.5 text-xs">
                      <span className="text-red-400 mt-0.5 shrink-0">⚠</span>
                      <span className="text-surface-600"><span className="font-medium text-red-600">Risk: </span>{reason.risk}</span>
                    </div>
                  )}
                </div>

                {/* Keyword pills */}
                <div className="flex flex-wrap gap-1">
                  {m.matched_keywords?.slice(0, 5).map((k: string, i: number) => (
                    <span key={i} className="px-1.5 py-0.5 bg-green-50 text-green-700 rounded text-[11px]">✓ {k}</span>
                  ))}
                  {m.missing_keywords?.slice(0, 4).map((k: string, i: number) => (
                    <span key={i} className="px-1.5 py-0.5 bg-red-50 text-red-600 rounded text-[11px]">✗ {k}</span>
                  ))}
                </div>

                {reason.resume && (
                  <p className="text-[10px] text-surface-400 italic">Scored using: {reason.resume}</p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── APPLICATIONS ── */}
      {tab === 'applications' && (
        <div className="space-y-3">
          {applications.length === 0 ? (
            <EmptyState icon={<ClipboardList size={24} />} title="No applications yet"
              description="Apply to matched jobs from the Matched Jobs tab" />
          ) : applications.map(a => (
            <div key={a.id} className="card p-4 space-y-3">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <p className="font-semibold text-surface-900">{a.job?.title}</p>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-surface-500 flex-wrap">
                    <span>{a.job?.company}</span>
                    {a.job?.location && <span className="flex items-center gap-0.5"><MapPin size={10} />{a.job.location}</span>}
                  </div>
                  <p className="text-xs text-surface-400 mt-1">
                    Applied {a.applied_at ? formatDate(a.applied_at) : formatRelative(a.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <StatusBadge status={a.status} />
                  {a.job?.url && (
                    <a href={a.job.url} target="_blank" rel="noreferrer" className="btn-ghost p-1.5">
                      <ExternalLink size={13} />
                    </a>
                  )}
                </div>
              </div>

              {/* Status pipeline */}
              <div className="pt-2 border-t border-surface-50">
                <div className="flex items-center">
                  {(['applied', 'screening', 'interview', 'offer'] as const).map((s, i, arr) => {
                    const statusOrder = ['applied', 'screening', 'interview', 'offer'];
                    const currentIdx = statusOrder.indexOf(a.status);
                    const isActive = i <= currentIdx && a.status !== 'rejected' && a.status !== 'withdrawn';
                    const isLast = i === arr.length - 1;
                    return (
                      <div key={s} className={cn('flex items-center', !isLast && 'flex-1')}>
                        <div className="flex flex-col items-center gap-1">
                          <div className={cn('w-5 h-5 rounded-full flex items-center justify-center shrink-0',
                            isActive ? 'bg-brand-600' : 'bg-surface-100')}>
                            {isActive ? <CheckCircle2 size={10} className="text-white" /> : <span className="text-[9px] text-surface-400">{i+1}</span>}
                          </div>
                          <span className="text-[9px] text-surface-400 capitalize whitespace-nowrap">{s}</span>
                        </div>
                        {!isLast && <div className={cn('flex-1 h-0.5 mx-1 -mt-3', isActive && i < currentIdx ? 'bg-brand-400' : 'bg-surface-100')} />}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── RESUMES ── */}
      {tab === 'resumes' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-surface-500">{uploadedResumes.length} / {MAX_RESUMES} resume variants</p>
            {uploadedResumes.length < MAX_RESUMES && (
              <button onClick={() => { setUploadError(null); setUploadLabel(''); setShowUploadModal(true); }}
                className="btn-primary text-sm flex items-center gap-1.5">
                <Plus size={14} /> Upload Resume
              </button>
            )}
          </div>

          {uploadedResumes.length === 0 ? (
            <EmptyState icon={<Upload size={24} />} title="No resumes uploaded"
              description="Upload up to 5 PDF resume variants. The AI uses your resume for more accurate ATS scoring."
              action={<button onClick={() => setShowUploadModal(true)} className="btn-primary text-sm flex items-center gap-1.5"><Plus size={14} /> Upload Resume</button>}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {uploadedResumes.map(r => (
                <div key={r.id} className="card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-lg bg-red-50 flex items-center justify-center shrink-0">
                        <FileText size={16} className="text-red-500" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-surface-900 truncate">{r.label}</p>
                        <p className="text-xs text-surface-400 truncate">{r.file_name}</p>
                        <p className="text-xs text-surface-400">{formatBytes(r.file_size)} · {formatRelative(r.uploaded_at)}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => downloadResume(r.pdf_path)} className="btn-ghost p-1.5" title="Download"><Download size={14} /></button>
                      <button onClick={() => setDeletingResume(r)} className="btn-ghost p-1.5 text-red-400 hover:text-red-600" title="Delete"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="card p-4 border-brand-100 bg-brand-50">
            <p className="text-xs text-brand-700 font-medium mb-1">💡 How resumes affect your ATS scores</p>
            <p className="text-xs text-brand-600">
              When you upload a resume, our AI reads the full content and scores your fit against each job — 
              giving you accurate ATS scores based on your actual resume, not just profile fields. 
              Upload multiple variants and the engine picks the best-scoring one per job.
            </p>
          </div>
        </div>
      )}

      {/* ── PROFILE ── */}
      {tab === 'profile' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-surface-900">My Profile</h2>
            {!editingProfile
              ? <button onClick={() => setEditingProfile(true)} className="btn-secondary text-sm">Edit Profile</button>
              : <div className="flex gap-2">
                  <button onClick={() => setEditingProfile(false)} className="btn-ghost text-sm">Cancel</button>
                  <button onClick={saveProfile} disabled={savingProfile} className="btn-primary text-sm min-w-[100px]">
                    {savingProfile ? <Spinner size={14} /> : 'Save Changes'}
                  </button>
                </div>
            }
          </div>

          {profileError && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 flex items-center gap-2">
              <AlertCircle size={14} /> {profileError}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="lg:col-span-2 space-y-5">
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Professional Summary</h3>
                {editingProfile
                  ? <textarea value={profileForm.summary}
                      onChange={e => setProfileForm((p: any) => ({ ...p, summary: e.target.value }))}
                      className="input text-sm h-28 resize-none w-full"
                      placeholder="Brief overview of your background and goals..." />
                  : <p className="text-sm text-surface-600 leading-relaxed">
                      {candidate.summary || <span className="text-surface-400 italic">No summary added</span>}
                    </p>
                }
              </div>

              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-4">Experience</h3>
                {(candidate.experience as any[])?.length > 0 ? (
                  <div className="space-y-4">
                    {(candidate.experience as any[]).map((exp: any, i: number) => (
                      <div key={i} className="border-l-2 border-brand-200 pl-4">
                        <p className="text-sm font-semibold text-surface-900">{exp.title}</p>
                        <p className="text-sm text-surface-600">{exp.company}</p>
                        <p className="text-xs text-surface-400 mt-0.5">
                          {exp.start_date} — {exp.current ? 'Present' : exp.end_date}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-surface-400">No experience on file. Contact your recruiter to update.</p>}
              </div>

              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Education</h3>
                {(candidate.education as any[])?.length > 0 ? (
                  <div className="space-y-3">
                    {(candidate.education as any[]).map((ed: any, i: number) => (
                      <div key={i}>
                        <p className="text-sm font-medium text-surface-800">{ed.degree} in {ed.field}</p>
                        <p className="text-sm text-surface-500">{ed.institution} · {ed.graduation_date}</p>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-surface-400">No education on file.</p>}
              </div>
            </div>

            <div className="space-y-4">
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Contact Info</h3>
                {editingProfile ? (
                  <div className="space-y-3">
                    {([
                      ['full_name', 'Full Name', 'text'],
                      ['phone', 'Phone', 'tel'],
                      ['location', 'Location', 'text'],
                      ['linkedin_url', 'LinkedIn URL', 'url'],
                      ['portfolio_url', 'Portfolio URL', 'url'],
                    ] as const).map(([key, label, type]) => (
                      <div key={key}>
                        <label className="label text-xs">{label}</label>
                        <input type={type} value={profileForm[key] || ''}
                          onChange={e => setProfileForm((p: any) => ({ ...p, [key]: e.target.value }))}
                          className="input text-sm" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 text-sm text-surface-600">
                    {candidate.email && <p className="flex items-center gap-2"><Mail size={13} className="text-surface-400" />{candidate.email}</p>}
                    {candidate.phone && <p className="flex items-center gap-2"><Phone size={13} className="text-surface-400" />{candidate.phone}</p>}
                    {candidate.location && <p className="flex items-center gap-2"><MapPin size={13} className="text-surface-400" />{candidate.location}</p>}
                    {candidate.linkedin_url && (
                      <a href={candidate.linkedin_url} target="_blank" rel="noreferrer"
                        className="flex items-center gap-2 text-brand-600 hover:underline">
                        <Linkedin size={13} />LinkedIn Profile
                      </a>
                    )}
                    {!candidate.email && !candidate.phone && !candidate.location && !candidate.linkedin_url && (
                      <p className="text-surface-400 italic text-xs">No contact info on file</p>
                    )}
                  </div>
                )}
              </div>

              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Skills</h3>
                <div className="flex flex-wrap gap-1.5">
                  {(candidate.skills as string[])?.map((s: string, i: number) => (
                    <span key={i} className="px-2.5 py-1 bg-brand-50 text-brand-700 rounded-lg text-xs font-medium">{s}</span>
                  ))}
                  {!candidate.skills?.length && <p className="text-xs text-surface-400 italic">No skills on file</p>}
                </div>
              </div>

              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-2">Work Authorization</h3>
                <p className="text-sm text-surface-600">
                  {candidate.visa_status || <span className="text-surface-400 italic">Not specified</span>}
                </p>
              </div>

              <div className="card p-4 bg-surface-50 border-surface-100">
                <p className="text-xs text-surface-500">
                  To update experience, education, or skills — contact your recruiter. You can update contact info and summary directly.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Upload Modal ── */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-surface-900">Upload Resume PDF</h3>
              <button onClick={() => setShowUploadModal(false)} className="btn-ghost p-1.5"><X size={16} /></button>
            </div>
            <div>
              <label className="label">Label <span className="text-surface-400 font-normal text-xs">e.g. "General", "Data Eng v2"</span></label>
              <input className="input text-sm" value={uploadLabel} onChange={e => setUploadLabel(e.target.value)} placeholder="General Resume" />
            </div>
            <div onClick={() => fileRef.current?.click()}
              className="border-2 border-dashed border-surface-300 rounded-xl p-8 text-center cursor-pointer hover:border-brand-400 hover:bg-brand-50 transition-colors">
              {uploading ? (
                <div className="flex flex-col items-center gap-2"><Spinner size={22} /><p className="text-sm text-surface-500">Uploading...</p></div>
              ) : (
                <>
                  <Upload size={24} className="mx-auto text-surface-400 mb-2" />
                  <p className="text-sm font-medium text-surface-700">Click to select PDF</p>
                  <p className="text-xs text-surface-400 mt-1">PDF only · max 10MB</p>
                </>
              )}
              <input ref={fileRef} type="file" accept="application/pdf" className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleUpload(f); }} />
            </div>
            {uploadError && <p className="text-xs text-red-600 flex items-center gap-1"><AlertCircle size={12} />{uploadError}</p>}
          </div>
        </div>
      )}

      {/* ── Delete Confirm ── */}
      {deletingResume && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 space-y-4">
            <h3 className="text-base font-semibold text-surface-900">Delete Resume</h3>
            <p className="text-sm text-surface-600">Delete <strong>{deletingResume.label}</strong>? This cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeletingResume(null)} className="btn-secondary text-sm">Cancel</button>
              <button onClick={handleDeleteResume} disabled={deleting} className="btn-primary text-sm !bg-red-600 !border-red-600">
                {deleting ? <Spinner size={14} /> : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}