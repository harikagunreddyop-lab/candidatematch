'use client';
// src/app/dashboard/candidate/waiting/page.tsx
// FIXED VERSION - Clearer messaging about approval process
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase-browser';
import { Spinner } from '@/components/ui';
import { Clock, CheckCircle2, Mail, UserCheck } from 'lucide-react';

export default function CandidateWaitingPage() {
  const supabase = createClient();
  const [name, setName] = useState('');
  const [checking, setChecking] = useState(false);
  const [approvalStatus, setApprovalStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');

  useEffect(() => {
    async function init() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: candidate } = await supabase
        .from('candidates')
        .select('full_name, approval_status')
        .eq('user_id', user.id)
        .single();
      setName(candidate?.full_name?.split(' ')[0] || '');
      setApprovalStatus(candidate?.approval_status || 'pending');
    }
    init();

    // Poll every 10 seconds for both approval and recruiter assignment
    const interval = setInterval(async () => {
      setChecking(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data: candidate } = await supabase
        .from('candidates')
        .select('id, approval_status, active')
        .eq('user_id', user.id)
        .single();
      
      if (!candidate) return;
      
      setApprovalStatus(candidate.approval_status || 'pending');
      
      // Check if approved and recruiter assigned
      if (candidate.approval_status === 'approved' && candidate.active) {
        const { count } = await supabase
          .from('recruiter_candidate_assignments')
          .select('recruiter_id', { count: 'exact', head: true })
          .eq('candidate_id', candidate.id);
        
        setChecking(false);
        
        if (count && count > 0) {
          // Recruiter assigned — redirect to dashboard
          window.location.href = '/dashboard/candidate';
        }
      } else {
        setChecking(false);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const steps = [
    { label: 'Invite sent', done: true },
    { label: 'Profile completed', done: true },
    { label: 'Admin approval', done: approvalStatus === 'approved', active: approvalStatus === 'pending' },
    { label: 'Recruiter assigned', done: false, active: approvalStatus === 'approved' },
    { label: 'Dashboard unlocked', done: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 text-center space-y-6">

        {/* Icon */}
        <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto">
          {approvalStatus === 'pending' ? (
            <Clock size={28} className="text-amber-600" />
          ) : (
            <UserCheck size={28} className="text-green-600" />
          )}
        </div>

        {/* Heading */}
        <div>
          <h1 className="text-2xl font-bold text-surface-900">
            {approvalStatus === 'pending' && `Almost there${name ? `, ${name}` : ''}!`}
            {approvalStatus === 'approved' && `Approved${name ? `, ${name}` : ''}! 🎉`}
            {approvalStatus === 'rejected' && 'Update Required'}
          </h1>
          <p className="text-sm text-surface-500 mt-2 leading-relaxed">
            {approvalStatus === 'pending' && 'Your profile is complete and under review. An admin will approve it shortly, then we\'ll assign you a dedicated recruiter.'}
            {approvalStatus === 'approved' && 'Your profile has been approved! We\'re now assigning you a recruiter who will help you find the perfect job.'}
            {approvalStatus === 'rejected' && 'Our admin has requested some updates to your profile. Please contact support for details.'}
          </p>
        </div>

        {/* Progress steps */}
        <div className="text-left space-y-3">
          {steps.map((s, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                s.done ? 'bg-green-500' :
                s.active ? 'bg-amber-400 animate-pulse' :
                'bg-surface-200'
              }`}>
                {s.done
                  ? <CheckCircle2 size={14} className="text-white" />
                  : <span className="text-[10px] font-bold text-white">{i + 1}</span>
                }
              </div>
              <span className={`text-sm ${
                s.done ? 'text-surface-700 font-medium' :
                s.active ? 'text-amber-700 font-semibold' :
                'text-surface-400'
              }`}>
                {s.label}
              </span>
              {s.active && checking && <Spinner size={12} />}
            </div>
          ))}
        </div>

        {/* What to expect */}
        {approvalStatus === 'pending' && (
          <div className="bg-surface-50 rounded-xl p-4 text-left space-y-2">
            <p className="text-xs font-semibold text-surface-700">⏱️ Typical timeline:</p>
            <div className="space-y-1 text-xs text-surface-600">
              <p>• <strong>Admin approval:</strong> Within 1 business day</p>
              <p>• <strong>Recruiter assignment:</strong> Immediately after approval</p>
              <p>• <strong>Dashboard access:</strong> Automatic once recruiter is assigned</p>
            </div>
          </div>
        )}

        {approvalStatus === 'approved' && (
          <div className="bg-green-50 rounded-xl p-4 text-left space-y-2">
            <p className="text-xs font-semibold text-green-800">✅ Your profile is approved!</p>
            <p className="text-xs text-green-700">We're assigning a recruiter right now. This page will automatically redirect you to your dashboard in a moment.</p>
          </div>
        )}

        {/* Email reminder */}
        <div className="flex items-center justify-center gap-2 text-xs text-surface-400">
          <Mail size={12} />
          <span>You'll receive email updates at each step</span>
        </div>

      </div>
    </div>
  );
}