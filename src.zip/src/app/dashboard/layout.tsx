import { requireAuth } from '@/lib/auth';
import DashboardLayout from '@/components/layout/DashboardLayout';

export default async function Layout({ children }: { children: React.ReactNode }) {
  try {
    const profile = await requireAuth();
    return <DashboardLayout profile={profile}>{children}</DashboardLayout>;
  } catch {
    return <>{children}</>;
  }
}