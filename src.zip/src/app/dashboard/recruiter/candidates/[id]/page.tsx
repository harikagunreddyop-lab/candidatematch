'use client';
// src/app/dashboard/recruiter/candidates/[id]/page.tsx

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase-browser';
import { Tabs, StatusBadge, Spinner, EmptyState } from '@/components/ui';
import {
  ArrowLeft, MapPin, Sparkles, Download, CheckCircle2,
  ExternalLink, FileText, Briefcase, Brain, Mail,
  Calendar, Phone, Linkedin, Star, Copy, Check,
  Save, Edit2, Plus, X, AlertCircle,
} from 'lucide-react';
import { formatDate, formatRelative, cn } from '@/utils/helpers';

const STATUS_OPTIONS = ['ready', 'applied', 'screening', 'interview', 'offer', 'rejected', 'withdrawn'];
const VISA_OPTIONS = ['US Citizen','Green Card','H1B','H4 EAD','L2 EAD','OPT','CPT','TN Visa','O1','Requires Sponsorship','Other'];
const AVAILABILITY_OPTIONS = ['Immediately','2 Weeks','1 Month','3 Months','Not Looking'];
const EDUCATION_LEVELS = ["High School","Associate's","Bachelor's","Master's","MBA","PhD","MD","JD","Bootcamp","Self-Taught","Other"];
const LANGUAGE_LEVELS = ['Basic','Conversational','Proficient','Fluent','Native'];

function safeArray(val: any): any[] {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  if (typeof val === 'string') {
    if (val === '{}') return [];
    try { return JSON.parse(val); } catch { return []; }
  }
  return [];
}

function scoreColor(score: number) {
  if (score >= 85) return 'bg-green-100 text-green-700';
  if (score >= 70) return 'bg-brand-100 text-brand-700';
  if (score >= 50) return 'bg-yellow-100 text-yellow-700';
  return 'bg-surface-100 text-surface-600';
}

function TagInput({
  value,
  onChange,
  placeholder,
}: {
  value: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
}) {
  const [input, setInput] = useState('');
  const inputId = useMemo(() => 'ti-' + Math.random().toString(36).slice(2, 7), []);
  const add = () => {
    const t = input.trim();
    if (t && !value.includes(t)) onChange([...value, t]);
    setInput('');
  };
  return (
    <div
      className="flex flex-wrap gap-1.5 p-2 border border-surface-200 rounded-lg min-h-[40px] cursor-text"
      onClick={() => document.getElementById(inputId)?.focus()}
    >
      {value.map((tag, i) => (
        <span
          key={i}
          className="flex items-center gap-1 px-2 py-0.5 bg-brand-100 text-brand-700 rounded-md text-xs font-medium"
        >
          {tag}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onChange(value.filter((_, j) => j !== i));
            }}
          >
            <X size={10} />
          </button>
        </span>
      ))}
      <input
        id={inputId}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            add();
          }
        }}
        onBlur={add}
        placeholder={value.length === 0 ? placeholder : ''}
        className="flex-1 min-w-[120px] outline-none text-xs bg-transparent placeholder-surface-400"
      />
    </div>
  );
}

export default function RecruiterCandidateDetail() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  // ✅ KEY FIX: useMemo ensures one stable client — never recreated on re-render
  const supabase = useMemo(() => createClient(), []);

  const [candidate, setCandidate] = useState<any>(null);
  const [matches, setMatches] = useState<any[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [resumes, setResumes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [notAssigned, setNotAssigned] = useState(false);
  const [tab, setTab] = useState('profile');

  const [editingProfile, setEditingProfile] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [profileForm, setProfileForm] = useState<any>({});

  const [generating, setGenerating] = useState<string | null>(null);
  const [briefJobId, setBriefJobId] = useState<string | null>(null);
  const [brief, setBrief] = useState<string | null>(null);
  const [briefLoading, setBriefLoading] = useState(false);
  const [emailJobId, setEmailJobId] = useState<string | null>(null);
  const [emailDraft, setEmailDraft] = useState<string | null>(null);
  const [emailLoading, setEmailLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const [schedulingAppId, setSchedulingAppId] = useState<string | null>(null);
  const [interviewDate, setInterviewDate] = useState('');
  const [interviewNotes, setInterviewNotes] = useState('');
  const [savingInterview, setSavingInterview] = useState(false);

  const initForm = useCallback((cand: any) => {
    setProfileForm({
      full_name: cand.full_name || '',
      primary_title: cand.primary_title || '',
      email: cand.email || '',
      phone: cand.phone || '',
      location: cand.location || '',
      linkedin_url: cand.linkedin_url || '',
      github_url: cand.github_url || '',
      portfolio_url: cand.portfolio_url || '',
      summary: cand.summary || '',
      visa_status: cand.visa_status || '',
      citizenship: cand.citizenship || '',
      skills: safeArray(cand.skills),
      soft_skills: safeArray(cand.soft_skills),
      tools: safeArray(cand.tools),
      languages: safeArray(cand.languages),
      years_of_experience: cand.years_of_experience?.toString() || '',
      highest_education: cand.highest_education || '',
      gpa: cand.gpa || '',
      experience: JSON.stringify(safeArray(cand.experience), null, 2),
      education: JSON.stringify(safeArray(cand.education), null, 2),
      certifications: JSON.stringify(safeArray(cand.certifications), null, 2),
      availability: cand.availability || '',
      notice_period: cand.notice_period || '',
      salary_min: cand.salary_min?.toString() || '',
      salary_max: cand.salary_max?.toString() || '',
      open_to_remote: cand.open_to_remote ?? true,
      open_to_relocation: cand.open_to_relocation ?? false,
      target_roles: safeArray(cand.target_roles),
      target_locations: safeArray(cand.target_locations),
      rating: cand.rating || 0,
      internal_notes: cand.internal_notes || '',
      interview_notes: cand.interview_notes || '',
      active: cand.active ?? true,
    });
  }, []);

  const load = useCallback(async (reinitForm = true) => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    const { data: assignment } = await supabase
      .from('recruiter_candidate_assignments')
      .select('candidate_id')
      .eq('recruiter_id', user.id)
      .eq('candidate_id', id)
      .single();

    if (!assignment) { setNotAssigned(true); setLoading(false); return; }

    const [candRes, matchRes, appRes, resumeRes] = await Promise.all([
      supabase.from('candidates').select('*').eq('id', id).single(),
      supabase.from('candidate_job_matches').select('*, job:jobs(*)').eq('candidate_id', id).order('fit_score', { ascending: false }),
      supabase.from('applications').select('*, job:jobs(*), resume_version:resume_versions(*)').eq('candidate_id', id).order('created_at', { ascending: false }),
      supabase.from('resume_versions').select('*, job:jobs(*)').eq('candidate_id', id).order('created_at', { ascending: false }),
    ]);

    const cand = candRes.data;
    setCandidate(cand);
    setMatches(matchRes.data || []);
    setApplications(appRes.data || []);
    setResumes(resumeRes.data || []);
    if (cand && reinitForm) initForm(cand);
    setLoading(false);
  }, [id, supabase, initForm]);

  // Load once on mount
  useEffect(() => { load(); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Realtime — don't reinit form while user is editing
  useEffect(() => {
    const channel = supabase.channel(`recruiter-candidate-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'candidates', filter: `id=eq.${id}` },
        () => { if (!editingProfile) load(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'applications', filter: `candidate_id=eq.${id}` },
        () => load(false))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id, supabase, editingProfile]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k: string, v: any) => setProfileForm((p: any) => ({ ...p, [k]: v }));

  const saveProfile = async () => {
    if (saving) return;
    setSaving(true);
    setSaveError(null);

    let experience, education, certifications;
    try {
      experience = JSON.parse(profileForm.experience || '[]');
      education = JSON.parse(profileForm.education || '[]');
      certifications = JSON.parse(profileForm.certifications || '[]');
    } catch {
      setSaveError('Invalid JSON in Experience, Education, or Certifications. Check the format and try again.');
      setSaving(false);
      return;
    }

    const { error } = await supabase.from('candidates').update({
      full_name: profileForm.full_name,
      primary_title: profileForm.primary_title,
      email: profileForm.email || null,
      phone: profileForm.phone || null,
      location: profileForm.location || null,
      linkedin_url: profileForm.linkedin_url || null,
      github_url: profileForm.github_url || null,
      portfolio_url: profileForm.portfolio_url || null,
      summary: profileForm.summary || null,
      visa_status: profileForm.visa_status || null,
      citizenship: profileForm.citizenship || null,
      skills: profileForm.skills,
      soft_skills: profileForm.soft_skills,
      tools: profileForm.tools,
      languages: profileForm.languages,
      years_of_experience: profileForm.years_of_experience ? parseInt(profileForm.years_of_experience) : null,
      highest_education: profileForm.highest_education || null,
      gpa: profileForm.gpa || null,
      experience,
      education,
      certifications,
      availability: profileForm.availability || null,
      notice_period: profileForm.notice_period || null,
      salary_min: profileForm.salary_min ? parseInt(profileForm.salary_min) : null,
      salary_max: profileForm.salary_max ? parseInt(profileForm.salary_max) : null,
      open_to_remote: profileForm.open_to_remote,
      open_to_relocation: profileForm.open_to_relocation,
      target_roles: profileForm.target_roles,
      target_locations: profileForm.target_locations,
      rating: profileForm.rating || null,
      internal_notes: profileForm.internal_notes || null,
      interview_notes: profileForm.interview_notes || null,
      active: profileForm.active,
      updated_at: new Date().toISOString(),
    }).eq('id', id);

    if (error) {
      console.error('[saveProfile] Supabase error:', error); // ← added
      setSaveError(error.message);
      setSaving(false);
      return;
    }

    // Sync to profiles table so admin views reflect changes
    const { data: candData } = await supabase.from('candidates').select('user_id').eq('id', id).single();
    if (candData?.user_id) {
      await supabase.from('profiles').update({
        name: profileForm.full_name,
        email: profileForm.email || null,
        updated_at: new Date().toISOString(),
      }).eq('id', candData.user_id);
    }

    setSaving(false);
    setSaveSuccess(true);
    setEditingProfile(false);
    setTimeout(() => setSaveSuccess(false), 3000);

    // Refresh from DB to confirm saved state
    const { data: fresh } = await supabase.from('candidates').select('*').eq('id', id).single();
    if (fresh) { setCandidate(fresh); initForm(fresh); }
  };

  const cancelEdit = () => {
    setEditingProfile(false);
    setSaveError(null);
    if (candidate) initForm(candidate);
  };

  const generateBrief = async (jobId: string) => {
    setBriefJobId(jobId); setBrief(null); setEmailJobId(null); setBriefLoading(true);
    try {
      const res = await fetch('/api/recruiter-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'brief', candidate_id: id, job_id: jobId }),
      });
      const data = await res.json();
      setBrief(data.result || data.error || 'Failed to generate');
    } catch {
      setBrief('Failed to generate brief');
    }
    setBriefLoading(false);
  };

  const generateEmail = async (jobId: string) => {
    setEmailJobId(jobId); setEmailDraft(null); setBriefJobId(null); setEmailLoading(true);
    try {
      const res = await fetch('/api/recruiter-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'email', candidate_id: id, job_id: jobId }),
      });
      const data = await res.json();
      setEmailDraft(data.result || data.error || 'Failed to generate');
    } catch {
      setEmailDraft('Failed to draft email');
    }
    setEmailLoading(false);
  };

  const generateResume = async (jobId: string) => {
    setGenerating(jobId);
    try {
      const res = await fetch('/api/resumes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ candidate_id: id, job_id: jobId }),
      });
      if (res.ok) await load(false);
    } catch (e) {
      console.error(e);
    }
    setGenerating(null);
  };

  const markApplied = async (jobId: string, resumeVersionId?: string) => {
    await supabase.from('applications').upsert(
      {
        candidate_id: id,
        job_id: jobId,
        resume_version_id: resumeVersionId ?? null,
        status: 'applied',
        applied_at: new Date().toISOString(),
      },
      { onConflict: 'candidate_id,job_id' }
    );
    await load(false);
  };

  const updateStatus = async (appId: string, status: string) => {
    await supabase.from('applications').update({ status }).eq('id', appId);
    await load(false);
  };

  const saveInterview = async (appId: string) => {
    setSavingInterview(true);
    await supabase.from('applications')
      .update({
        status: 'interview',
        interview_date: interviewDate || null,
        notes: interviewNotes || null,
      })
      .eq('id', appId);
    setSchedulingAppId(null);
    setSavingInterview(false);
    await load(false);
  };

  const downloadResume = async (pdfPath: string) => {
    const { data } = await supabase.storage.from('resumes').createSignedUrl(pdfPath, 300);
    if (data?.signedUrl) window.open(data.signedUrl, '_blank');
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>;
  if (notAssigned) return (
    <div className="text-center py-20 space-y-3">
      <p className="text-surface-500 text-sm">This candidate is not assigned to you.</p>
      <button onClick={() => router.back()} className="btn-secondary text-sm">Go Back</button>
    </div>
  );
  if (!candidate) return <p className="text-surface-500 text-sm py-10 text-center">Candidate not found.</p>;

  const skills = safeArray(candidate.skills);
  const experience = safeArray(candidate.experience);
  const education = safeArray(candidate.education);

  return (
    <div className="space-y-6">
      {/* Header — Edit Profile toggle only, NO save button here */}
      <div className="flex items-center gap-4">
        <button onClick={() => router.back()} className="btn-ghost p-2"><ArrowLeft size={18} /></button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold text-surface-900 font-display">{candidate.full_name}</h1>
            <span className={cn(
              'px-2 py-0.5 rounded-full text-xs font-medium',
              candidate.active ? 'bg-green-100 text-green-700' : 'bg-surface-100 text-surface-500'
            )}>
              {candidate.active ? 'Active' : 'Inactive'}
            </span>
            {candidate.rating > 0 && (
              <div className="flex gap-0.5">
                {Array.from({ length: candidate.rating }).map((_: any, i: number) => (
                  <Star key={i} size={12} className="text-amber-400 fill-amber-400" />
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-3 mt-1 flex-wrap text-sm text-surface-500">
            <span className="font-medium text-surface-700">
              {candidate.primary_title || <span className="italic text-surface-400">No title yet</span>}
            </span>
            {candidate.location && <span className="flex items-center gap-1"><MapPin size={12} />{candidate.location}</span>}
            {candidate.email && <a href={`mailto:${candidate.email}`} className="flex items-center gap-1 hover:text-brand-600"><Mail size={12} />{candidate.email}</a>}
            {candidate.phone && <a href={`tel:${candidate.phone}`} className="flex items-center gap-1 hover:text-brand-600"><Phone size={12} />{candidate.phone}</a>}
            {candidate.linkedin_url && <a href={candidate.linkedin_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-brand-600"><Linkedin size={12} />LinkedIn</a>}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {saveSuccess && (
            <span className="flex items-center gap-1 text-xs text-green-600 font-medium">
              <CheckCircle2 size={13} /> Saved!
            </span>
          )}
          {/* Only show Edit Profile when NOT editing — Save is only in the sticky bottom bar */}
          {!editingProfile && (
            <button onClick={() => setEditingProfile(true)} className="btn-secondary text-sm flex items-center gap-1.5">
              <Edit2 size={13} /> Edit Profile
            </button>
          )}
        </div>
      </div>

      {saveError && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 flex items-center gap-2">
          <AlertCircle size={14} /> {saveError}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Matches', value: matches.length, color: 'text-brand-600' },
          { label: 'Applications', value: applications.length, color: 'text-purple-600' },
          { label: 'Resumes', value: resumes.length, color: 'text-amber-600' },
          { label: 'Top Score', value: matches[0]?.fit_score ?? '—', color: 'text-green-600' },
        ].map((s) => (
          <div key={s.label} className="card p-3 text-center">
            <p className={cn('text-xl font-bold', s.color)}>{s.value}</p>
            <p className="text-xs text-surface-500">{s.label}</p>
          </div>
        ))}
      </div>

      <Tabs
        tabs={[
          { key: 'profile', label: editingProfile ? '✏️ Editing Profile' : 'Profile' },
          { key: 'matches', label: 'Matching Jobs', count: matches.length },
          { key: 'applications', label: 'Applications', count: applications.length },
          { key: 'resumes', label: 'Resumes', count: resumes.length },
        ]}
        active={tab}
        onChange={setTab}
      />

      {/* ── PROFILE TAB ── */}
      {tab === 'profile' && (
        editingProfile ? (
          <div className="space-y-6">
            {/* Basic Info */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Basic Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Full Name <span className="text-red-500">*</span></label>
                  <input value={profileForm.full_name} onChange={(e) => set('full_name', e.target.value)} className="input text-sm" />
                </div>
                <div>
                  <label className="label">Primary Title <span className="text-red-500">*</span></label>
                  <input value={profileForm.primary_title} onChange={(e) => set('primary_title', e.target.value)} className="input text-sm" placeholder="Data Analyst" />
                </div>
                <div>
                  <label className="label">Email</label>
                  <input value={profileForm.email} onChange={(e) => set('email', e.target.value)} className="input text-sm" type="email" />
                </div>
                <div>
                  <label className="label">Phone</label>
                  <input value={profileForm.phone} onChange={(e) => set('phone', e.target.value)} className="input text-sm" type="tel" />
                </div>
                <div>
                  <label className="label">Location</label>
                  <input value={profileForm.location} onChange={(e) => set('location', e.target.value)} className="input text-sm" placeholder="New York, NY" />
                </div>
                <div>
                  <label className="label">LinkedIn URL</label>
                  <input value={profileForm.linkedin_url} onChange={(e) => set('linkedin_url', e.target.value)} className="input text-sm" />
                </div>
                <div>
                  <label className="label">GitHub URL</label>
                  <input value={profileForm.github_url} onChange={(e) => set('github_url', e.target.value)} className="input text-sm" />
                </div>
                <div>
                  <label className="label">Portfolio URL</label>
                  <input value={profileForm.portfolio_url} onChange={(e) => set('portfolio_url', e.target.value)} className="input text-sm" />
                </div>
                <div>
                  <label className="label">Visa / Work Auth</label>
                  <select value={profileForm.visa_status} onChange={(e) => set('visa_status', e.target.value)} className="input text-sm" aria-label="Visa status">
                    <option value="">— Select —</option>
                    {VISA_OPTIONS.map((v) => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Citizenship</label>
                  <input value={profileForm.citizenship} onChange={(e) => set('citizenship', e.target.value)} className="input text-sm" placeholder="US, India..." />
                </div>
                <div className="col-span-2">
                  <label className="label">Professional Summary</label>
                  <textarea value={profileForm.summary} onChange={(e) => set('summary', e.target.value)} className="input text-sm h-24 resize-none" />
                </div>
                <div className="col-span-2 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => set('active', !profileForm.active)}
                    className={cn('relative w-10 h-5 rounded-full transition-colors shrink-0', profileForm.active ? 'bg-brand-600' : 'bg-surface-300')}
                  >
                    <span className={cn('absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform', profileForm.active ? 'translate-x-5' : 'translate-x-0.5')} />
                  </button>
                  <span className="text-sm text-surface-700">{profileForm.active ? 'Active — visible in matching' : 'Inactive — excluded from matching'}</span>
                </div>
              </div>
            </div>

            {/* Skills */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Skills & Expertise</h3>
              <div className="space-y-4">
                <div>
                  <label className="label">Technical Skills <span className="text-xs text-surface-400 font-normal">press Enter to add</span></label>
                  <TagInput value={profileForm.skills} onChange={(v) => set('skills', v)} placeholder="Python, SQL, Tableau..." />
                </div>
                <div>
                  <label className="label">Tools & Software</label>
                  <TagInput value={profileForm.tools} onChange={(v) => set('tools', v)} placeholder="Excel, Power BI, Jira..." />
                </div>
                <div>
                  <label className="label">Soft Skills</label>
                  <TagInput value={profileForm.soft_skills} onChange={(v) => set('soft_skills', v)} placeholder="Communication, Leadership..." />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Years of Experience</label>
                    <input value={profileForm.years_of_experience} onChange={(e) => set('years_of_experience', e.target.value)} className="input text-sm" type="number" min="0" max="50" />
                  </div>
                  <div>
                    <label className="label">Highest Education</label>
                    <select value={profileForm.highest_education} onChange={(e) => set('highest_education', e.target.value)} className="input text-sm" aria-label="Education level">
                      <option value="">— Select —</option>
                      {EDUCATION_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="label">Languages</label>
                  <div className="space-y-2">
                    {profileForm.languages.map((lang: any, i: number) => (
                      <div key={i} className="flex items-center gap-2">
                        <input
                          value={lang.language}
                          onChange={(e) => {
                            const l = [...profileForm.languages];
                            l[i] = { ...l[i], language: e.target.value };
                            set('languages', l);
                          }}
                          className="input text-sm flex-1"
                          placeholder="Language"
                        />
                        <select
                          value={lang.level}
                          onChange={(e) => {
                            const l = [...profileForm.languages];
                            l[i] = { ...l[i], level: e.target.value };
                            set('languages', l);
                          }}
                          className="input text-sm w-36"
                          aria-label="Level"
                        >
                          {LANGUAGE_LEVELS.map((lvl) => <option key={lvl} value={lvl}>{lvl}</option>)}
                        </select>
                        <button type="button" onClick={() => set('languages', profileForm.languages.filter((_: any, j: number) => j !== i))} className="btn-ghost p-1.5 text-red-400"><X size={14} /></button>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => set('languages', [...profileForm.languages, { language: '', level: 'Conversational' }])}
                      className="btn-ghost text-xs flex items-center gap-1 text-brand-600"
                    >
                      <Plus size={12} />Add language
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Experience / Education / Certs */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Experience & Education</h3>
              <div className="space-y-4">
                {([
                  ['experience', 'Work Experience', 'h-44', '[{"company":"Acme","title":"Data Analyst","start_date":"2021-01","end_date":"","current":true,"location":"NYC","responsibilities":["Built dashboards"]}]'],
                  ['education', 'Education', 'h-28', '[{"institution":"University Name","degree":"BS","field":"Statistics","graduation_date":"2021-05"}]'],
                  ['certifications', 'Certifications', 'h-24', '[{"name":"Google Analytics","issuer":"Google","date":"2023-01"}]'],
                ] as const).map(([key, label, h, ph]) => (
                  <div key={key}>
                    <label className="label">{label} <span className="text-surface-400 text-xs font-normal">(JSON)</span></label>
                    <textarea value={profileForm[key]} onChange={(e) => set(key, e.target.value)} className={cn('input text-sm resize-none font-mono text-xs w-full', h)} placeholder={ph} />
                  </div>
                ))}
              </div>
            </div>

            {/* Preferences */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Preferences</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Availability</label>
                  <select value={profileForm.availability} onChange={(e) => set('availability', e.target.value)} className="input text-sm" aria-label="Availability">
                    <option value="">— Select —</option>
                    {AVAILABILITY_OPTIONS.map((a) => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Notice Period</label>
                  <input value={profileForm.notice_period} onChange={(e) => set('notice_period', e.target.value)} className="input text-sm" placeholder="2 weeks" />
                </div>
                <div>
                  <label className="label">Salary Min (USD/yr)</label>
                  <input value={profileForm.salary_min} onChange={(e) => set('salary_min', e.target.value)} className="input text-sm" type="number" placeholder="80000" />
                </div>
                <div>
                  <label className="label">Salary Max (USD/yr)</label>
                  <input value={profileForm.salary_max} onChange={(e) => set('salary_max', e.target.value)} className="input text-sm" type="number" placeholder="120000" />
                </div>
                <div className="col-span-2 flex gap-6">
                  {([['open_to_remote', 'Open to remote'], ['open_to_relocation', 'Open to relocation']] as const).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={profileForm[key]} onChange={(e) => set(key, e.target.checked)} className="rounded border-surface-300 text-brand-600 w-4 h-4" />
                      <span className="text-sm text-surface-700">{label}</span>
                    </label>
                  ))}
                </div>
                <div className="col-span-2">
                  <label className="label">Target Roles</label>
                  <TagInput value={profileForm.target_roles} onChange={(v) => set('target_roles', v)} placeholder="Data Analyst, BI Developer..." />
                </div>
                <div className="col-span-2">
                  <label className="label">Target Locations</label>
                  <TagInput value={profileForm.target_locations} onChange={(v) => set('target_locations', v)} placeholder="New York, Remote..." />
                </div>
              </div>
            </div>

            {/* Notes */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-surface-800 mb-4">Internal Notes</h3>
              <div className="space-y-4">
                <div>
                  <label className="label">Rating</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button key={n} type="button" onClick={() => set('rating', n === profileForm.rating ? 0 : n)}>
                        <Star size={18} className={cn(n <= profileForm.rating ? 'text-amber-400 fill-amber-400' : 'text-surface-300')} />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="label">Internal Notes <span className="text-xs text-surface-400 font-normal">not visible to candidate</span></label>
                  <textarea value={profileForm.internal_notes} onChange={(e) => set('internal_notes', e.target.value)} className="input text-sm h-20 resize-none" />
                </div>
                <div>
                  <label className="label">Interview Notes</label>
                  <textarea value={profileForm.interview_notes} onChange={(e) => set('interview_notes', e.target.value)} className="input text-sm h-20 resize-none" />
                </div>
              </div>
            </div>

            {/* ✅ ONLY save button — sticky at bottom, nowhere else */}
            <div className="sticky bottom-4 z-10">
              <div className="card px-4 py-3 flex items-center gap-3 shadow-xl border border-surface-200 bg-white">
                {saveError && (
                  <p className="text-xs text-red-600 flex items-center gap-1 flex-1 min-w-0">
                    <AlertCircle size={12} className="shrink-0" /><span className="truncate">{saveError}</span>
                  </p>
                )}
                <div className="flex items-center gap-2 ml-auto shrink-0">
                  <button onClick={cancelEdit} className="btn-secondary text-sm">Cancel</button>
                  <button
                    onClick={saveProfile}
                    disabled={saving || !profileForm.full_name || !profileForm.primary_title}
                    className="btn-primary text-sm flex items-center gap-1.5 min-w-[120px] justify-center"
                  >
                    {saving ? <Spinner size={14} /> : <Save size={13} />}
                    {saving ? 'Saving...' : 'Save Profile'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          // ── VIEW MODE ──
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-5">
              {candidate.summary && (
                <div className="card p-5">
                  <h3 className="text-sm font-semibold text-surface-800 mb-2">Summary</h3>
                  <p className="text-sm text-surface-600 leading-relaxed">{candidate.summary}</p>
                </div>
              )}
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-4">Experience</h3>
                {experience.length > 0 ? (
                  <div className="space-y-4">
                    {experience.map((exp: any, i: number) => (
                      <div key={i} className="border-l-2 border-brand-200 pl-4">
                        <p className="text-sm font-semibold text-surface-900">{exp.title}</p>
                        <p className="text-sm text-surface-600">{exp.company}{exp.location ? ` · ${exp.location}` : ''}</p>
                        <p className="text-xs text-surface-400 mt-0.5">{exp.start_date} — {exp.current ? 'Present' : exp.end_date}</p>
                        {safeArray(exp.responsibilities).slice(0, 3).map((r: string, j: number) => (
                          <p key={j} className="text-xs text-surface-500 mt-1 pl-2 before:content-['•'] before:mr-1">{r}</p>
                        ))}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-sm text-surface-400 mb-3">No experience added yet</p>
                    <button onClick={() => setEditingProfile(true)} className="btn-primary text-xs flex items-center gap-1 mx-auto"><Edit2 size={12} /> Add Experience</button>
                  </div>
                )}
              </div>
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Education</h3>
                {education.length > 0 ? (
                  <div className="space-y-3">
                    {education.map((ed: any, i: number) => (
                      <div key={i}>
                        <p className="text-sm font-medium text-surface-800">{ed.degree} in {ed.field}</p>
                        <p className="text-sm text-surface-500">{ed.institution} · {ed.graduation_date}</p>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-surface-400">No education added yet</p>}
              </div>
              {candidate.internal_notes && (
                <div className="card p-5 border-amber-100 bg-amber-50">
                  <h3 className="text-sm font-semibold text-surface-800 mb-2">Internal Notes</h3>
                  <p className="text-xs text-surface-700 leading-relaxed">{candidate.internal_notes}</p>
                </div>
              )}
            </div>
            <div className="space-y-5">
              <div className="card p-5 space-y-2">
                <h3 className="text-sm font-semibold text-surface-800 mb-3">Details</h3>
                {candidate.visa_status && <p className="text-xs text-surface-600">🛂 {candidate.visa_status}</p>}
                {candidate.availability && <p className="text-xs text-surface-600">📅 {candidate.availability}</p>}
                {candidate.salary_min && <p className="text-xs text-surface-600">💰 ${Math.round(candidate.salary_min / 1000)}k{candidate.salary_max ? `–$${Math.round(candidate.salary_max / 1000)}k` : '+'}</p>}
                {candidate.open_to_remote && <p className="text-xs text-surface-600">🌐 Open to remote</p>}
                {candidate.open_to_relocation && <p className="text-xs text-surface-600">✈️ Open to relocation</p>}
                {candidate.years_of_experience && <p className="text-xs text-surface-600">📊 {candidate.years_of_experience} years experience</p>}
              </div>
              {skills.length > 0 ? (
                <div className="card p-5">
                  <h3 className="text-sm font-semibold text-surface-800 mb-3">Skills</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {skills.map((s: string, i: number) => <span key={i} className="px-2 py-0.5 bg-brand-50 text-brand-700 rounded text-xs">{s}</span>)}
                  </div>
                </div>
              ) : (
                <div className="card p-5 text-center">
                  <p className="text-xs text-surface-400 mb-2">No skills added yet</p>
                  <button onClick={() => setEditingProfile(true)} className="btn-primary text-xs flex items-center gap-1 mx-auto"><Edit2 size={12} /> Add Skills</button>
                </div>
              )}
            </div>
          </div>
        )
      )}

      {/* ── MATCHES TAB ── */}
      {tab === 'matches' && (
        <div className="space-y-3">
          {matches.length === 0 ? (
            <EmptyState icon={<Briefcase size={24} />} title="No matches yet" description="The matching engine hasn't run for this candidate yet" />
          ) : matches.map((m) => (
            <div key={m.id} className="card p-4">
              <div className="flex items-start gap-4">
                <span className={cn('shrink-0 w-12 h-12 rounded-xl flex items-center justify-center text-sm font-bold', scoreColor(m.fit_score))}>
                  {m.fit_score}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <p className="font-semibold text-surface-900">{m.job?.title}</p>
                      <p className="text-sm text-surface-500">{m.job?.company} · {m.job?.location || 'Location not listed'}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                      {m.job?.url && <a href={m.job.url} target="_blank" rel="noopener noreferrer" className="btn-ghost text-xs p-1.5"><ExternalLink size={13} /></a>}
                      <button onClick={() => generateEmail(m.job_id)} className="btn-ghost text-xs flex items-center gap-1 py-1.5 px-2.5 text-purple-600 hover:bg-purple-50"><Mail size={12} /> Email</button>
                      <button onClick={() => generateBrief(m.job_id)} className="btn-ghost text-xs flex items-center gap-1 py-1.5 px-2.5 text-brand-600 hover:bg-brand-50"><Brain size={12} /> Brief</button>
                      <button onClick={() => generateResume(m.job_id)} disabled={generating === m.job_id} className="btn-primary text-xs py-1.5 px-3 flex items-center gap-1">
                        {generating === m.job_id ? <Spinner size={12} /> : <Sparkles size={12} />} Resume
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {safeArray(m.matched_keywords).slice(0, 5).map((k: string, i: number) => <span key={i} className="px-1.5 py-0.5 bg-green-50 text-green-700 rounded text-[11px]">✓ {k}</span>)}
                    {safeArray(m.missing_keywords).slice(0, 3).map((k: string, i: number) => <span key={i} className="px-1.5 py-0.5 bg-red-50 text-red-600 rounded text-[11px]">✗ {k}</span>)}
                  </div>
                </div>
              </div>

              {briefJobId === m.job_id && (
                <div className="mt-4 pt-4 border-t border-surface-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain size={14} className="text-brand-600" />
                    <p className="text-xs font-semibold text-brand-700">Pre-Call Brief</p>
                    <button onClick={() => setBriefJobId(null)} className="ml-auto text-xs text-surface-400">✕</button>
                  </div>
                  {briefLoading ? (
                    <div className="flex items-center gap-2 text-xs text-surface-500 py-3"><Spinner size={14} /> Generating…</div>
                  ) : (
                    <div className="text-xs text-surface-700 leading-relaxed whitespace-pre-wrap bg-surface-50 rounded-lg p-4">{brief}</div>
                  )}
                </div>
              )}

              {emailJobId === m.job_id && (
                <div className="mt-4 pt-4 border-t border-surface-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Mail size={14} className="text-purple-600" />
                    <p className="text-xs font-semibold text-purple-700">Outreach Email</p>
                    <button onClick={() => setEmailJobId(null)} className="ml-auto text-xs text-surface-400">✕</button>
                  </div>
                  {emailLoading ? (
                    <div className="flex items-center gap-2 text-xs text-surface-500 py-3"><Spinner size={14} /> Drafting…</div>
                  ) : (
                    <div className="space-y-2">
                      <div className="bg-surface-50 rounded-lg p-4 text-xs text-surface-700 leading-relaxed whitespace-pre-wrap">{emailDraft}</div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(emailDraft || '');
                          setCopied(true);
                          setTimeout(() => setCopied(false), 2000);
                        }}
                        className="btn-ghost text-xs flex items-center gap-1.5"
                      >
                        {copied ? <><Check size={12} className="text-green-500" /> Copied!</> : <><Copy size={12} /> Copy</>}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── APPLICATIONS TAB ── */}
      {tab === 'applications' && (
        <div className="space-y-3">
          {applications.length === 0
            ? <EmptyState icon={<FileText size={24} />} title="No applications yet" description="Generate a resume then click Mark Applied" />
            : applications.map((a) => (
              <div key={a.id} className="card p-4">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <p className="font-semibold text-surface-900">{a.job?.title}</p>
                    <p className="text-sm text-surface-500">{a.job?.company} · {a.job?.location || '—'}</p>
                    <p className="text-xs text-surface-400 mt-0.5">Applied {a.applied_at ? formatDate(a.applied_at) : '—'}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <StatusBadge status={a.status} />
                    <select value={a.status} onChange={(e) => updateStatus(a.id, e.target.value)} className="input text-xs py-1 px-2 w-32" aria-label="Update status">
                      {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                {a.status === 'interview' && (
                  <div className="mt-3 pt-3 border-t border-surface-100">
                    {schedulingAppId === a.id ? (
                      <div className="space-y-2">
                        <div className="flex gap-2">
                          <input type="datetime-local" value={interviewDate} onChange={(e) => setInterviewDate(e.target.value)} className="input text-xs py-1 flex-1" />
                          <button onClick={() => saveInterview(a.id)} disabled={savingInterview} className="btn-primary text-xs px-3 py-1">
                            {savingInterview ? <Spinner size={12} /> : 'Save'}
                          </button>
                          <button onClick={() => setSchedulingAppId(null)} className="btn-ghost text-xs px-2">✕</button>
                        </div>
                        <textarea value={interviewNotes} onChange={(e) => setInterviewNotes(e.target.value)} placeholder="Notes…" className="input text-xs h-16 resize-none w-full" />
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          setSchedulingAppId(a.id);
                          setInterviewDate(a.interview_date?.slice(0, 16) || '');
                          setInterviewNotes(a.notes || '');
                        }}
                        className="btn-ghost text-xs flex items-center gap-1.5 text-purple-600"
                      >
                        <Calendar size={12} />
                        {a.interview_date ? `Interview: ${formatDate(a.interview_date)} — Edit` : '+ Schedule interview'}
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
        </div>
      )}

      {/* ── RESUMES TAB ── */}
      {tab === 'resumes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {resumes.length === 0
            ? <EmptyState icon={<FileText size={24} />} title="No resumes yet" description="Generate one from the Matching Jobs tab" />
            : resumes.map((r) => (
              <div key={r.id} className="card p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-semibold text-surface-900">{r.job?.title}</p>
                    <p className="text-xs text-surface-500">{r.job?.company} · v{r.version_number}</p>
                  </div>
                  <StatusBadge status={r.generation_status} />
                </div>
                <p className="text-xs text-surface-400 mt-2">{formatRelative(r.created_at)}</p>
                {r.generation_status === 'completed' && (
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => downloadResume(r.pdf_path)} className="btn-secondary text-xs py-1.5 flex items-center gap-1">
                      <Download size={13} /> Download
                    </button>
                    <button onClick={() => markApplied(r.job_id, r.id)} className="btn-primary text-xs py-1.5 flex items-center gap-1">
                      <CheckCircle2 size={13} /> Mark Applied
                    </button>
                  </div>
                )}
              </div>
            ))}
        </div>
      )}
    </div>
  );
}