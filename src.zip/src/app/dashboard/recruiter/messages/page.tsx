'use client';
import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase-browser';
import { useProfile } from '@/hooks';
import { Spinner, SearchInput } from '@/components/ui';
import { MessageCircle, Plus, X } from 'lucide-react';
import {
  ChatPanel, ConversationItem, OnlineDot,
  type Conversation, type ConversationParticipant,
} from '@/components/ui/ChatComponents';
import type { Profile } from '@/types';

export default function RecruiterMessagesPage() {
  const { profile, loading: profileLoading } = useProfile();
  const supabase = createClient();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showNewConv, setShowNewConv] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<Profile[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);

  const loadConversations = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data: partRows } = await supabase
      .from('conversation_participants').select('conversation_id').eq('profile_id', profile.id);
    if (!partRows?.length) { setConversations([]); setLoading(false); return; }

    const convIds = partRows.map(r => r.conversation_id);
    const [convRes, partRes, msgRes, unreadRes] = await Promise.all([
      supabase.from('conversations').select('*').in('id', convIds).order('updated_at', { ascending: false }),
      supabase.from('conversation_participants')
        .select('*, profile:profiles!profile_id(id, name, email, role)')
        .in('conversation_id', convIds),
      supabase.from('messages').select('*').in('conversation_id', convIds).order('created_at', { ascending: false }),
      supabase.from('conversation_participants')
        .select('conversation_id, last_read_at').eq('profile_id', profile.id).in('conversation_id', convIds),
    ]);

    const participants: ConversationParticipant[] = partRes.data || [];
    const allMessages = msgRes.data || [];
    const myReadMap: Record<string, string | null> = {};
    for (const r of (unreadRes.data || [])) myReadMap[r.conversation_id] = r.last_read_at;

    const convs: Conversation[] = (convRes.data || []).map(c => {
      const convParticipants = participants.filter(p => p.conversation_id === c.id);
      const convMessages = allMessages.filter(m => m.conversation_id === c.id);
      const lastRead = myReadMap[c.id];
      const unread = lastRead
        ? convMessages.filter(m => m.sender_id !== profile.id && new Date(m.created_at) > new Date(lastRead)).length
        : convMessages.filter(m => m.sender_id !== profile.id).length;
      return { ...c, participants: convParticipants, last_message: convMessages[0] || null, unread_count: unread };
    });
    setConversations(convs);
    setLoading(false);
  }, [profile]);

  useEffect(() => { loadConversations(); }, [loadConversations]);

  useEffect(() => {
    if (!profile) return;
    const channel = supabase.channel('recruiter-messages-page')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => loadConversations())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, () => loadConversations())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile, loadConversations]);

  const loadAvailableUsers = async () => {
    if (!profile) return;
    const { data: assignments } = await supabase
      .from('recruiter_candidate_assignments')
      .select('candidate_id, candidate:candidates!candidate_id(user_id)')
      .eq('recruiter_id', profile.id);
    const candidateUserIds = (assignments || []).map((a: any) => a.candidate?.user_id).filter(Boolean);
    const { data: admins } = await supabase.from('profiles').select('*').eq('role', 'admin');
    const { data: candidates } = candidateUserIds.length
      ? await supabase.from('profiles').select('*').in('id', candidateUserIds)
      : { data: [] };
    setAvailableUsers([...(admins || []), ...(candidates || [])].filter(u => u.id !== profile.id));
  };

  const createConversation = async () => {
    if (!profile || !selectedUsers.length) return;
    setCreating(true);
    const { data: conv } = await supabase.from('conversations').insert({ created_by: profile.id }).select().single();
    if (conv) {
      await supabase.from('conversation_participants').insert(
        [profile.id, ...selectedUsers].map(pid => ({ conversation_id: conv.id, profile_id: pid }))
      );
      await loadConversations();
      setActiveConvId(conv.id);
      setShowNewConv(false);
      setSelectedUsers([]);
    }
    setCreating(false);
  };

  const filtered = conversations.filter(c => {
    if (!search) return true;
    const others = c.participants?.filter(p => p.profile_id !== profile?.id) || [];
    return others.some(p =>
      p.profile?.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.profile?.email?.toLowerCase().includes(search.toLowerCase())
    );
  });

  const totalUnread = conversations.reduce((a, c) => a + (c.unread_count || 0), 0);

  if (profileLoading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>;
  if (!profile) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 font-display">Messages</h1>
          <p className="text-sm text-surface-500 mt-1">
            Your conversations {totalUnread > 0 && <span className="text-brand-600 font-medium">· {totalUnread} unread</span>}
          </p>
        </div>
        <button onClick={() => { setShowNewConv(true); loadAvailableUsers(); }}
          className="btn-primary text-sm flex items-center gap-1.5">
          <Plus size={16} /> New Conversation
        </button>
      </div>

      <div className="h-[calc(100vh-200px)] bg-white rounded-2xl border border-surface-200 shadow-sm overflow-hidden flex">
        {/* Sidebar */}
        <div className="w-72 border-r border-surface-200 flex flex-col shrink-0">
          <div className="p-3 border-b border-surface-200">
            <SearchInput value={search} onChange={setSearch} placeholder="Search..." />
          </div>
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center h-32"><Spinner size={20} /></div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 gap-2 px-4 text-center">
                <MessageCircle size={28} className="text-surface-300" />
                <p className="text-sm text-surface-400">No conversations yet</p>
                <button onClick={() => { setShowNewConv(true); loadAvailableUsers(); }}
                  className="btn-primary text-xs flex items-center gap-1"><Plus size={12} />Start one</button>
              </div>
            ) : (
              <div className="divide-y divide-surface-50">
                {filtered.map(conv => (
                  <ConversationItem key={conv.id} conv={conv} active={activeConvId === conv.id}
                    onClick={() => setActiveConvId(conv.id)} currentProfileId={profile.id} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Chat / New conv */}
        <div className="flex-1 overflow-hidden">
          {showNewConv ? (
            <div className="h-full overflow-y-auto p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-surface-900">New Conversation</h3>
                <button onClick={() => { setShowNewConv(false); setSelectedUsers([]); }} className="btn-ghost p-1.5"><X size={16} /></button>
              </div>
              <p className="text-xs font-semibold text-surface-400 uppercase tracking-wide mb-3">Your candidates & admins</p>
              <div className="space-y-1 mb-6">
                {availableUsers.length === 0 && <p className="text-sm text-surface-400">No users to message. Assign candidates first.</p>}
                {availableUsers.map(u => (
                  <label key={u.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-surface-50 cursor-pointer">
                    <input type="checkbox" checked={selectedUsers.includes(u.id)}
                      onChange={e => setSelectedUsers(prev => e.target.checked ? [...prev, u.id] : prev.filter(id => id !== u.id))}
                      className="rounded border-surface-300 text-brand-600" />
                    <div className="relative shrink-0">
                      <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-sm">
                        {(u.name || u.email || '?')[0].toUpperCase()}
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5"><OnlineDot profileId={u.id} /></div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-surface-800">{u.name || u.email}</p>
                      <p className="text-xs text-surface-400 capitalize">{u.role}</p>
                    </div>
                  </label>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={() => { setShowNewConv(false); setSelectedUsers([]); }} className="btn-secondary flex-1">Cancel</button>
                <button onClick={createConversation} disabled={!selectedUsers.length || creating} className="btn-primary flex-1">
                  {creating ? <Spinner size={14} /> : 'Start Chat'}
                </button>
              </div>
            </div>
          ) : activeConvId ? (
            <ChatPanel conversationId={activeConvId} currentProfile={profile} onUnreadChange={loadConversations} />
          ) : (
            <div className="flex flex-col items-center justify-center h-full gap-3 text-center px-8">
              <div className="w-16 h-16 rounded-2xl bg-brand-50 flex items-center justify-center">
                <MessageCircle size={28} className="text-brand-400" />
              </div>
              <p className="text-surface-800 font-medium">Select a conversation</p>
              <p className="text-sm text-surface-400">Message your assigned candidates or the admin team</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}