'use client';
// src/app/dashboard/recruiter/page.tsx
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase-browser';
import { Spinner } from '@/components/ui';
import { Users, Briefcase, ChevronRight, Star, Calendar, Sparkles, Bell, ArrowUpRight, TrendingUp } from 'lucide-react';
import { cn } from '@/utils/helpers';

function scoreColor(score: number) {
  if (score >= 85) return 'bg-green-100 text-green-700';
  if (score >= 70) return 'bg-brand-100 text-brand-700';
  if (score >= 50) return 'bg-yellow-100 text-yellow-700';
  return 'bg-surface-100 text-surface-600';
}

export default function RecruiterDashboard() {
  const [pageData, setPageData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [greeting, setGreeting] = useState('');
  const supabase = createClient();

  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening');
  }, []);

  useEffect(() => {
    async function load() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      const rid = session.user.id;

      const { data: profile } = await supabase
        .from('profiles').select('name').eq('id', rid).single();

      // ── Step 1: get all candidate IDs assigned to this recruiter ──────────
      const { data: assignments } = await supabase
        .from('recruiter_candidate_assignments')
        .select('candidate_id')
        .eq('recruiter_id', rid);

      const allIds = (assignments || []).map((a: any) => a.candidate_id as string);

      if (allIds.length === 0) {
        setPageData({ profile, candList: [], newMatches: [], todayInterviews: [], pipeline: {}, totalAssigned: 0 });
        setLoading(false);
        return;
      }

      // ── Step 2: active candidates for the "My Candidates" widget ─────────
      const { data: cands } = await supabase
        .from('candidates')
        .select('id, full_name, primary_title, rating')
        .in('id', allIds)
        .eq('active', true)
        .order('full_name')
        .limit(6);

      const yesterday = new Date(Date.now() - 86400000).toISOString();
      const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
      const todayEnd = new Date(); todayEnd.setHours(23, 59, 59, 999);

      // ── Step 3: all dashboard data in parallel ────────────────────────────
      const [newMatchRes, interviewRes, appRes] = await Promise.all([
        // New matches since yesterday — ALL assigned candidates
        supabase.from('candidate_job_matches')
          .select('id, fit_score, candidate_id, matched_at, job:jobs(title, company), candidate:candidates(full_name)')
          .in('candidate_id', allIds)
          .gte('matched_at', yesterday)
          .order('fit_score', { ascending: false })
          .limit(5),

        // Today's interviews — uses interview_date column (added in migration 002_fixes)
        // Wrapped in try-catch in case column doesn't exist yet
        supabase.from('applications')
          .select('id, candidate_id, candidate:candidates(full_name), job:jobs(title, company)')
          .in('candidate_id', allIds)
          .eq('status', 'interview'),

        // Application status counts for pipeline — ALL assigned candidates
        supabase.from('applications')
          .select('status')
          .in('candidate_id', allIds),
      ]);

      // Build pipeline counts
      const pipeline: Record<string, number> = {};
      for (const app of appRes.data || []) {
        pipeline[app.status] = (pipeline[app.status] || 0) + 1;
      }

      setPageData({
        profile,
        candList: cands || [],
        newMatches: newMatchRes.data || [],
        todayInterviews: interviewRes.data || [],
        pipeline,
        totalAssigned: allIds.length,
      });
      setLoading(false);
    }
    load();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>;
  if (!pageData) return null;

  const { profile, candList, newMatches, todayInterviews, pipeline, totalAssigned } = pageData;
  const totalApps = Object.values(pipeline).reduce((a: any, b: any) => a + b, 0) as number;

  const STAGES = [
    { key: 'applied',   label: 'Applied',   color: 'text-blue-600' },
    { key: 'screening', label: 'Screening', color: 'text-yellow-600' },
    { key: 'interview', label: 'Interview', color: 'text-purple-600' },
    { key: 'offer',     label: 'Offer',     color: 'text-green-600' },
    { key: 'rejected',  label: 'Rejected',  color: 'text-red-500' },
    { key: 'ready',     label: 'Ready',     color: 'text-surface-500' },
  ];

  const BAR_COLORS: Record<string, string> = {
    applied: 'bg-blue-400', screening: 'bg-yellow-400',
    interview: 'bg-purple-400', offer: 'bg-green-400',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 font-display">
            {greeting}, {profile?.name?.split(' ')[0] || 'Recruiter'} 👋
          </h1>
          <p className="text-sm text-surface-500 mt-1">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <Link href="/dashboard/recruiter/pipeline" className="btn-primary text-sm flex items-center gap-2">
          <Briefcase size={14} /> Pipeline Board
        </Link>
      </div>

      {/* Alert banners — only shown when there's something to act on */}
      {(newMatches.length > 0 || todayInterviews.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {newMatches.length > 0 && (
            <div className="rounded-xl bg-brand-50 border border-brand-100 px-4 py-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-brand-100 flex items-center justify-center shrink-0">
                <Bell size={15} className="text-brand-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-brand-900">
                  {newMatches.length} new job match{newMatches.length !== 1 ? 'es' : ''}
                </p>
                <p className="text-xs text-brand-600">since yesterday</p>
              </div>
              <Link href="/dashboard/recruiter/candidates" className="shrink-0">
                <ArrowUpRight size={16} className="text-brand-500" />
              </Link>
            </div>
          )}
          {todayInterviews.length > 0 && (
            <div className="rounded-xl bg-purple-50 border border-purple-100 px-4 py-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center shrink-0">
                <Calendar size={15} className="text-purple-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-purple-900">
                  {todayInterviews.length} interview{todayInterviews.length !== 1 ? 's' : ''} today
                </p>
                <p className="text-xs text-purple-600 truncate">
                  {todayInterviews.map((i: any) => i.candidate?.full_name).join(', ')}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Pipeline snapshot — only shown when there are applications */}
      {totalApps > 0 && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-surface-800">Pipeline Snapshot</h2>
            <Link href="/dashboard/recruiter/pipeline"
              className="text-xs text-brand-600 hover:underline flex items-center gap-1">
              Full board <ChevronRight size={12} />
            </Link>
          </div>
          <div className="grid grid-cols-6 gap-3 text-center">
            {STAGES.map(s => (
              <div key={s.key}>
                <p className={cn('text-2xl font-bold', s.color)}>{pipeline[s.key] || 0}</p>
                <p className="text-[10px] text-surface-400 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
          {/* Proportional progress bar */}
          <div className="mt-4 flex rounded-full overflow-hidden h-1.5 bg-surface-100">
            {['applied', 'screening', 'interview', 'offer'].map(stage => {
              const pct = totalApps > 0 ? ((pipeline[stage] || 0) / totalApps) * 100 : 0;
              return pct > 0
                ? <div key={stage} style={{ width: `${pct}%` }} className={cn('h-full', BAR_COLORS[stage])} />
                : null;
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* New Matches widget */}
        <div className="card overflow-hidden">
          <div className="px-5 py-3.5 border-b border-surface-100 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-surface-800 flex items-center gap-2">
              <Sparkles size={14} className="text-brand-500" /> New Matches
            </h2>
            <Link href="/dashboard/recruiter/candidates"
              className="text-xs text-brand-600 hover:underline flex items-center gap-1">
              All candidates <ChevronRight size={12} />
            </Link>
          </div>
          {newMatches.length === 0 ? (
            <div className="p-8 text-center">
              <TrendingUp size={22} className="mx-auto text-surface-300 mb-2" />
              <p className="text-sm text-surface-500">No new matches since yesterday</p>
            </div>
          ) : (
            <div className="divide-y divide-surface-50">
              {newMatches.map((m: any) => (
                <Link key={m.id} href={`/dashboard/recruiter/candidates/${m.candidate_id}`}
                  className="flex items-center gap-3 px-5 py-3 hover:bg-surface-50 transition-colors">
                  <span className={cn('shrink-0 w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold', scoreColor(m.fit_score))}>
                    {m.fit_score}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-surface-900 truncate">{m.job?.title}</p>
                    <p className="text-xs text-surface-500 truncate">{m.job?.company} · {m.candidate?.full_name}</p>
                  </div>
                  <ChevronRight size={13} className="text-surface-300 shrink-0" />
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* My Candidates widget */}
        <div className="card overflow-hidden">
          <div className="px-5 py-3.5 border-b border-surface-100 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-surface-800 flex items-center gap-2">
              <Users size={14} className="text-surface-500" /> My Candidates
              {/* totalAssigned counts ALL including inactive — matches admin count */}
              <span className="text-xs text-surface-400 font-normal">({totalAssigned})</span>
            </h2>
            <Link href="/dashboard/recruiter/candidates"
              className="text-xs text-brand-600 hover:underline flex items-center gap-1">
              View all <ChevronRight size={12} />
            </Link>
          </div>
          {totalAssigned === 0 ? (
            <div className="p-8 text-center">
              <Users size={22} className="mx-auto text-surface-300 mb-2" />
              <p className="text-sm text-surface-500">No candidates assigned yet</p>
              <p className="text-xs text-surface-400 mt-1">Ask your admin to assign candidates</p>
            </div>
          ) : (
            <div className="divide-y divide-surface-50">
              {candList.map((c: any) => (
                <Link key={c.id} href={`/dashboard/recruiter/candidates/${c.id}`}
                  className="flex items-center gap-3 px-5 py-3 hover:bg-surface-50 transition-colors group">
                  <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-xs shrink-0">
                    {c.full_name?.[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-surface-900 truncate">{c.full_name}</p>
                    <p className="text-xs text-surface-500 truncate">{c.primary_title}</p>
                  </div>
                  {c.rating > 0 && (
                    <div className="flex gap-0.5 shrink-0">
                      {Array.from({ length: c.rating }).map((_: any, i: number) => (
                        <Star key={i} size={10} className="text-amber-400 fill-amber-400" />
                      ))}
                    </div>
                  )}
                  <ChevronRight size={13} className="text-surface-300 group-hover:text-surface-500 shrink-0" />
                </Link>
              ))}
              {totalAssigned > 6 && (
                <Link href="/dashboard/recruiter/candidates"
                  className="flex items-center justify-center gap-1 px-5 py-2.5 text-xs text-brand-600 hover:bg-surface-50 transition-colors">
                  +{totalAssigned - 6} more <ChevronRight size={11} />
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}