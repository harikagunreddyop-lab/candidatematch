'use client';
// src/app/dashboard/recruiter/pipeline/page.tsx
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase-browser';
import { Spinner } from '@/components/ui';
import { MapPin, Star, GripVertical, ExternalLink, Calendar } from 'lucide-react';
import { cn, formatDate } from '@/utils/helpers';

const STAGES = [
  { key: 'ready',     label: 'New Matches', color: 'bg-surface-100', header: 'bg-surface-200 text-surface-700' },
  { key: 'applied',   label: 'Applied',     color: 'bg-blue-50',     header: 'bg-blue-100 text-blue-700' },
  { key: 'screening', label: 'Screening',   color: 'bg-yellow-50',   header: 'bg-yellow-100 text-yellow-700' },
  { key: 'interview', label: 'Interview',   color: 'bg-purple-50',   header: 'bg-purple-100 text-purple-700' },
  { key: 'offer',     label: 'Offer',       color: 'bg-green-50',    header: 'bg-green-100 text-green-700' },
  { key: 'rejected',  label: 'Rejected',    color: 'bg-red-50',      header: 'bg-red-100 text-red-600' },
];

function scoreColor(score: number) {
  if (score >= 85) return 'bg-green-100 text-green-700';
  if (score >= 70) return 'bg-brand-100 text-brand-700';
  if (score >= 50) return 'bg-yellow-100 text-yellow-700';
  return 'bg-surface-100 text-surface-600';
}

export default function PipelinePage() {
  const [cards, setCards] = useState<Record<string, any[]>>({});
  const [loading, setLoading] = useState(true);
  const [dragging, setDragging] = useState<{ card: any; fromStage: string } | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const supabase = createClient();

  const load = useCallback(async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    // Get all assigned candidate IDs
    const { data: assignments } = await supabase
      .from('recruiter_candidate_assignments')
      .select('candidate_id')
      .eq('recruiter_id', session.user.id);

    const ids = (assignments || []).map((a: any) => a.candidate_id as string);

    if (ids.length === 0) {
      const empty: Record<string, any[]> = {};
      STAGES.forEach(s => empty[s.key] = []);
      setCards(empty);
      setLoading(false);
      return;
    }

    // Fetch applications and top matches in parallel
    const [appRes, matchRes] = await Promise.all([
      supabase.from('applications')
        .select('*, candidate:candidates(id, full_name, primary_title, location, rating), job:jobs(id, title, company, location, url)')
        .in('candidate_id', ids)
        .order('updated_at', { ascending: false }),
      supabase.from('candidate_job_matches')
        .select('*, candidate:candidates(id, full_name, primary_title, location, rating), job:jobs(id, title, company, location, url)')
        .in('candidate_id', ids)
        .gte('fit_score', 60)
        .order('fit_score', { ascending: false })
        .limit(50),
    ]);

    // Group applications by status
    const grouped: Record<string, any[]> = {};
    STAGES.forEach(s => grouped[s.key] = []);

    for (const app of appRes.data || []) {
      const stage = app.status || 'ready';
      if (grouped[stage]) grouped[stage].push({ ...app, _type: 'application' });
    }

    // Matches not yet applied → "ready" column
    const appliedKeys = new Set(
      (appRes.data || []).map((a: any) => `${a.candidate_id}:${a.job_id}`)
    );
    for (const m of matchRes.data || []) {
      const key = `${m.candidate_id}:${m.job_id}`;
      if (!appliedKeys.has(key)) {
        grouped['ready'].push({ ...m, _type: 'match' });
      }
    }

    setCards(grouped);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const moveCard = async (card: any, toStage: string) => {
    if (card._type === 'match') {
      // Create a new application row
      await supabase.from('applications').upsert({
        candidate_id: card.candidate_id,
        job_id: card.job_id,
        status: toStage,
        applied_at: toStage === 'applied' ? new Date().toISOString() : null,
      }, { onConflict: 'candidate_id,job_id' });
    } else {
      await supabase.from('applications').update({ status: toStage }).eq('id', card.id);
    }
    await load();
  };

  const onDrop = async (toStage: string) => {
    if (!dragging || dragging.fromStage === toStage) {
      setDragging(null); setDragOver(null); return;
    }
    await moveCard(dragging.card, toStage);
    setDragging(null); setDragOver(null);
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>;

  const totalCards = Object.values(cards).reduce((sum, col) => sum + col.length, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 font-display">Pipeline Board</h1>
          <p className="text-sm text-surface-500 mt-1">
            {totalCards} active positions · drag cards to update status
          </p>
        </div>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-4" style={{ minHeight: '70vh' }}>
        {STAGES.map(stage => {
          const stageCards = cards[stage.key] || [];
          const isOver = dragOver === stage.key;

          return (
            <div
              key={stage.key}
              className={cn(
                'flex-shrink-0 w-64 rounded-xl flex flex-col transition-colors',
                stage.color,
                isOver && 'ring-2 ring-brand-400'
              )}
              onDragOver={e => { e.preventDefault(); setDragOver(stage.key); }}
              onDragLeave={e => {
                // only clear if leaving the column entirely (not into a child)
                if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragOver(null);
              }}
              onDrop={() => onDrop(stage.key)}
            >
              {/* Column header */}
              <div className={cn('flex items-center justify-between px-3 py-2.5 rounded-t-xl text-xs font-semibold', stage.header)}>
                <span>{stage.label}</span>
                <span className="opacity-70">{stageCards.length}</span>
              </div>

              {/* Cards */}
              <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                {stageCards.map((card: any) => (
                  <PipelineCard
                    key={card.id || `${card.candidate_id}:${card.job_id}`}
                    card={card}
                    stage={stage.key}
                    onDragStart={() => setDragging({ card, fromStage: stage.key })}
                    onMove={moveCard}
                  />
                ))}
                {stageCards.length === 0 && (
                  <div className={cn(
                    'h-16 rounded-lg border-2 border-dashed flex items-center justify-center text-xs',
                    isOver ? 'border-brand-400 text-brand-500' : 'border-surface-200 text-surface-300'
                  )}>
                    {isOver ? 'Drop here' : 'Empty'}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PipelineCard({ card, stage, onDragStart, onMove }: {
  card: any;
  stage: string;
  onDragStart: () => void;
  onMove: (card: any, stage: string) => void;
}) {
  const candidate = card.candidate;
  const job = card.job;
  const isMatch = card._type === 'match';

  const NEXT_STAGE: Record<string, string | null> = {
    ready: 'applied', applied: 'screening', screening: 'interview',
    interview: 'offer', offer: null, rejected: null,
  };
  const NEXT_LABELS: Record<string, string> = {
    ready: '→ Apply', applied: '→ Screen', screening: '→ Interview', interview: '→ Offer',
  };
  const NEXT_COLORS: Record<string, string> = {
    ready: 'bg-blue-100 text-blue-700 hover:bg-blue-200',
    applied: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200',
    screening: 'bg-purple-100 text-purple-700 hover:bg-purple-200',
    interview: 'bg-green-100 text-green-700 hover:bg-green-200',
  };

  const nextStage = NEXT_STAGE[stage];

  return (
    <div
      draggable
      onDragStart={onDragStart}
      className="bg-white rounded-lg p-3 shadow-sm border border-surface-100 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow group"
    >
      {/* Candidate row */}
      <div className="flex items-start gap-2">
        <div className="w-7 h-7 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-xs shrink-0">
          {candidate?.full_name?.[0] || '?'}
        </div>
        <div className="flex-1 min-w-0">
          <Link
            href={`/dashboard/recruiter/candidates/${card.candidate_id}`}
            className="text-xs font-semibold text-surface-900 hover:text-brand-600 leading-tight truncate block"
            onClick={e => e.stopPropagation()}
          >
            {candidate?.full_name}
          </Link>
          <p className="text-[10px] text-surface-500 truncate">{candidate?.primary_title}</p>
        </div>
        <GripVertical size={12} className="text-surface-300 shrink-0 mt-0.5" />
      </div>

      {/* Job row */}
      <div className="mt-2 pt-2 border-t border-surface-50">
        <p className="text-[11px] font-medium text-surface-800 truncate">{job?.title}</p>
        <p className="text-[10px] text-surface-500 truncate">{job?.company}</p>
        {job?.location && (
          <p className="text-[10px] text-surface-400 flex items-center gap-0.5 mt-0.5">
            <MapPin size={9} />{job.location}
          </p>
        )}
      </div>

      {/* Fit score (matches only) */}
      {isMatch && card.fit_score && (
        <div className="mt-2">
          <span className={cn('text-[10px] font-bold px-1.5 py-0.5 rounded', scoreColor(card.fit_score))}>
            {card.fit_score} fit
          </span>
        </div>
      )}

      {/* Rating */}
      {(candidate?.rating ?? 0) > 0 && (
        <div className="flex gap-0.5 mt-1.5">
          {Array.from({ length: candidate.rating }).map((_: any, i: number) => (
            <Star key={i} size={8} className="text-amber-400 fill-amber-400" />
          ))}
        </div>
      )}

      {/* Interview date */}
      {stage === 'interview' && card.interview_date && (
        <div className="mt-2 flex items-center gap-1 text-[10px] text-purple-600">
          <Calendar size={9} /> {formatDate(card.interview_date)}
        </div>
      )}

      {/* Hover actions */}
      <div className="mt-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        {job?.url && (
          <a href={job.url} target="_blank" rel="noopener noreferrer"
            className="text-[10px] text-surface-400 hover:text-brand-600 flex items-center gap-0.5"
            onClick={e => e.stopPropagation()}>
            <ExternalLink size={9} /> Job
          </a>
        )}
        {nextStage && (
          <div className="ml-auto">
            <button
              onClick={() => onMove(card, nextStage)}
              className={cn('text-[10px] px-1.5 py-0.5 rounded transition-colors', NEXT_COLORS[stage])}
            >
              {NEXT_LABELS[stage]}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}