import { createServerSupabase } from './supabase-server';
import { redirect } from 'next/navigation';
import type { Profile, Role } from '@/types';

export async function getSession() {
  const supabase = createServerSupabase();
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

export async function getProfile(): Promise<Profile | null> {
  const supabase = createServerSupabase();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;

  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', session.user.id)
    .single();

  return data;
}

export async function requireAuth(): Promise<Profile> {
  const profile = await getProfile();
  if (!profile) redirect('/');
  return profile;
}

export async function requireRole(roles: Role[]): Promise<Profile> {
  const profile = await requireAuth();
  if (!roles.includes(profile.role)) redirect('/dashboard');
  return profile;
}

export function getRoleDashboardPath(role: Role): string {
  switch (role) {
    case 'admin': return '/dashboard/admin';
    case 'recruiter': return '/dashboard/recruiter';
    case 'candidate': return '/dashboard/candidate';
    default: return '/';
  }
}
