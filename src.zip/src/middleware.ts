import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

// Which roles are allowed on which route prefixes
// Added 'admin' to candidate routes for oversight capabilities
const ROLE_ROUTES: Record<string, string[]> = {
  '/dashboard/admin':     ['admin'],
  '/dashboard/recruiter': ['recruiter', 'admin'],
  '/dashboard/candidate': ['candidate', 'admin'],
};

export async function middleware(request: NextRequest) {
  // Initialize response early
  let response = NextResponse.next({ request: { headers: request.headers } });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({ name, value, ...options });
          // Refresh response to apply cookie changes
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({ name, value: '', ...options });
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value: '', ...options });
        },
      },
    }
  );

  // Securely fetch user - validates JWT with Supabase Auth server
  const { data: { user }, error } = await supabase.auth.getUser();

  // If there is an error or no user, treat as logged out
  if (error) console.warn('Middleware Auth Warning:', error.message);

  const pathname = request.nextUrl.pathname;

  // ── Not logged in → send to login page ──────────────────────────────────
  if (pathname.startsWith('/dashboard') && !user) {
    return NextResponse.redirect(new URL('/', request.url));
  }

  // ── Logged in Logic ──────────────────────────────────────────────────────
  if (user) {
    // Fetch role once
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const role = profile?.role as string | undefined;

    // ── On login page (root) → redirect to correct dashboard ──────────────
    if (pathname === '/') {
      if (!role) return response; // No role found, stay on page or handle error

      const dest = role === 'admin' ? '/dashboard/admin'
                 : role === 'recruiter' ? '/dashboard/recruiter'
                 : '/dashboard/candidate';
      return NextResponse.redirect(new URL(dest, request.url));
    }

    // ── On a dashboard route → check permissions ───────────────────────────
    if (pathname.startsWith('/dashboard')) {
      const matchedPrefix = Object.keys(ROLE_ROUTES).find(prefix => pathname.startsWith(prefix));

      // Role Check: If route is protected and user has a role
      if (matchedPrefix && role) {
        const allowedRoles = ROLE_ROUTES[matchedPrefix];
        if (!allowedRoles.includes(role)) {
          // User tried to access a route they don't belong to
          const dest = role === 'admin' ? '/dashboard/admin'
                     : role === 'recruiter' ? '/dashboard/recruiter'
                     : '/dashboard/candidate';
          return NextResponse.redirect(new URL(dest, request.url));
        }
      }

      // /dashboard root → redirect to role-specific dashboard
      if (pathname === '/dashboard' && role) {
        const dest = role === 'admin' ? '/dashboard/admin'
                   : role === 'recruiter' ? '/dashboard/recruiter'
                   : '/dashboard/candidate';
        return NextResponse.redirect(new URL(dest, request.url));
      }

      // ── Candidate Access Gates ───────────────────────────────────────────
      const isCandidate = role === 'candidate';
      const isCandidateDashboard = pathname.startsWith('/dashboard/candidate');
      const isOnboardingPage = pathname === '/dashboard/candidate/onboarding';
      const isWaitingPage = pathname === '/dashboard/candidate/waiting';

      // Only run heavy checks for candidates on their dashboard routes
      if (isCandidate && isCandidateDashboard && !isOnboardingPage && !isWaitingPage) {
        const { data: candidate } = await supabase
          .from('candidates')
          .select('id, onboarding_completed')
          .eq('user_id', user.id)
          .single();

        // Gate 1: Onboarding not done
        if (!candidate || !candidate.onboarding_completed) {
          return NextResponse.redirect(new URL('/dashboard/candidate/onboarding', request.url));
        }

        // Gate 2: No recruiter assigned
        const { count } = await supabase
          .from('recruiter_candidate_assignments')
          .select('recruiter_id', { count: 'exact', head: true })
          .eq('candidate_id', candidate.id);

        if (!count || count === 0) {
          return NextResponse.redirect(new URL('/dashboard/candidate/waiting', request.url));
        }
      }

      // Prevent looping: Redirect away from onboarding/waiting if already done
      if (isCandidate && (isOnboardingPage || isWaitingPage)) {
        const { data: candidate } = await supabase
          .from('candidates')
          .select('id, onboarding_completed')
          .eq('user_id', user.id)
          .single();

        if (candidate?.onboarding_completed) {
           // Check assignment
           const { count } = await supabase
            .from('recruiter_candidate_assignments')
            .select('recruiter_id', { count: 'exact', head: true })
            .eq('candidate_id', candidate.id);

           // If they have a recruiter, they belong on the dashboard, not waiting
           if (count && count > 0) {
             return NextResponse.redirect(new URL('/dashboard/candidate', request.url));
           }
           // If on onboarding but completed, send to waiting (or dashboard if assigned)
           if (isOnboardingPage) {
             const dest = count && count > 0 ? '/dashboard/candidate' : '/dashboard/candidate/waiting';
             return NextResponse.redirect(new URL(dest, request.url));
           }
        }
      }
    }
  }

  return response;
}

export const config = {
  matcher: ['/', '/dashboard/:path*'],
};