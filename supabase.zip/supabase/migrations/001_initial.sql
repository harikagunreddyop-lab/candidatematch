-- ============================================================================
-- CandidateMatch Resume Factory — Complete Database Migration
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- TABLES
-- ============================================================================

-- Profiles (extends auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'candidate' CHECK (role IN ('admin', 'recruiter', 'candidate')),
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Candidates
CREATE TABLE IF NOT EXISTS public.candidates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  location TEXT,
  visa_status TEXT,
  primary_title TEXT NOT NULL,
  secondary_titles TEXT[] DEFAULT '{}',
  skills JSONB DEFAULT '[]',
  experience JSONB DEFAULT '[]',
  education JSONB DEFAULT '[]',
  certifications JSONB DEFAULT '[]',
  summary TEXT DEFAULT '',
  linkedin_url TEXT,
  portfolio_url TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Recruiter → Candidate assignments
CREATE TABLE IF NOT EXISTS public.recruiter_candidate_assignments (
  recruiter_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (recruiter_id, candidate_id)
);

-- Jobs
CREATE TABLE IF NOT EXISTS public.jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source TEXT NOT NULL DEFAULT 'manual',
  source_job_id TEXT,
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  location TEXT,
  url TEXT,
  jd_raw TEXT,
  jd_clean TEXT,
  salary_min INTEGER,
  salary_max INTEGER,
  job_type TEXT,
  remote_type TEXT,
  dedupe_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  scraped_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Candidate ↔ Job matches
CREATE TABLE IF NOT EXISTS public.candidate_job_matches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  fit_score INTEGER NOT NULL DEFAULT 0 CHECK (fit_score >= 0 AND fit_score <= 100),
  matched_keywords TEXT[] DEFAULT '{}',
  missing_keywords TEXT[] DEFAULT '{}',
  match_reason TEXT,
  matched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(candidate_id, job_id)
);

-- Resume versions
CREATE TABLE IF NOT EXISTS public.resume_versions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  pdf_path TEXT NOT NULL,
  bullets JSONB DEFAULT '[]',
  generation_status TEXT NOT NULL DEFAULT 'pending' CHECK (generation_status IN ('pending', 'generating', 'compiling', 'uploading', 'completed', 'failed')),
  error_message TEXT,
  version_number INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Applications
CREATE TABLE IF NOT EXISTS public.applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES public.candidates(id) ON DELETE CASCADE,
  job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  resume_version_id UUID REFERENCES public.resume_versions(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'ready' CHECK (status IN ('ready', 'applied', 'screening', 'interview', 'offer', 'rejected', 'withdrawn')),
  applied_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(candidate_id, job_id)
);

-- Scrape runs (tracking)
CREATE TABLE IF NOT EXISTS public.scrape_runs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  actor_id TEXT NOT NULL,
  search_query TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed')),
  jobs_found INTEGER DEFAULT 0,
  jobs_new INTEGER DEFAULT 0,
  jobs_duplicate INTEGER DEFAULT 0,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  error_message TEXT
);

-- ============================================================================
-- INDEXES
-- ============================================================================

CREATE INDEX idx_profiles_role ON public.profiles(role);
CREATE INDEX idx_profiles_email ON public.profiles(email);

CREATE INDEX idx_candidates_active ON public.candidates(active);
CREATE INDEX idx_candidates_primary_title ON public.candidates(primary_title);
CREATE INDEX idx_candidates_user_id ON public.candidates(user_id);

CREATE INDEX idx_jobs_dedupe_hash ON public.jobs(dedupe_hash);
CREATE INDEX idx_jobs_source_job_id ON public.jobs(source, source_job_id);
CREATE INDEX idx_jobs_title ON public.jobs(title);
CREATE INDEX idx_jobs_company ON public.jobs(company);
CREATE INDEX idx_jobs_scraped_at ON public.jobs(scraped_at DESC);
CREATE INDEX idx_jobs_active ON public.jobs(is_active);

CREATE INDEX idx_matches_candidate ON public.candidate_job_matches(candidate_id);
CREATE INDEX idx_matches_job ON public.candidate_job_matches(job_id);
CREATE INDEX idx_matches_score ON public.candidate_job_matches(fit_score DESC);

CREATE INDEX idx_resume_versions_candidate ON public.resume_versions(candidate_id);
CREATE INDEX idx_resume_versions_job ON public.resume_versions(job_id);
CREATE INDEX idx_resume_versions_status ON public.resume_versions(generation_status);

CREATE INDEX idx_applications_candidate ON public.applications(candidate_id);
CREATE INDEX idx_applications_job ON public.applications(job_id);
CREATE INDEX idx_applications_status ON public.applications(status);

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.email, ''),
    'candidate'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers
CREATE TRIGGER set_updated_at_profiles
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER set_updated_at_candidates
  BEFORE UPDATE ON public.candidates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER set_updated_at_applications
  BEFORE UPDATE ON public.applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Job deduplication function
CREATE OR REPLACE FUNCTION public.generate_job_hash(
  p_title TEXT,
  p_company TEXT,
  p_location TEXT,
  p_jd TEXT
) RETURNS TEXT AS $$
BEGIN
  RETURN encode(
    digest(
      LOWER(TRIM(COALESCE(p_title, ''))) || '|' ||
      LOWER(TRIM(COALESCE(p_company, ''))) || '|' ||
      LOWER(TRIM(COALESCE(p_location, ''))) || '|' ||
      LEFT(LOWER(TRIM(COALESCE(p_jd, ''))), 500),
      'sha256'
    ),
    'hex'
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Matching score function
CREATE OR REPLACE FUNCTION public.calculate_fit_score(
  candidate_skills JSONB,
  candidate_titles TEXT[],
  job_title TEXT,
  job_description TEXT
) RETURNS TABLE(score INTEGER, matched TEXT[], missing TEXT[]) AS $$
DECLARE
  skill_list TEXT[];
  jd_lower TEXT;
  title_lower TEXT;
  matched_arr TEXT[] := '{}';
  missing_arr TEXT[] := '{}';
  total_score INTEGER := 0;
  skill TEXT;
  title TEXT;
BEGIN
  jd_lower := LOWER(COALESCE(job_description, ''));
  title_lower := LOWER(COALESCE(job_title, ''));

  -- Extract skill names from JSONB array
  SELECT ARRAY_AGG(LOWER(elem::TEXT)) INTO skill_list
  FROM jsonb_array_elements_text(COALESCE(candidate_skills, '[]'::jsonb)) AS elem;

  IF skill_list IS NOT NULL THEN
    FOREACH skill IN ARRAY skill_list LOOP
      IF jd_lower LIKE '%' || skill || '%' THEN
        matched_arr := array_append(matched_arr, skill);
      ELSE
        missing_arr := array_append(missing_arr, skill);
      END IF;
    END LOOP;

    -- Skill match score (0-60)
    IF array_length(skill_list, 1) > 0 THEN
      total_score := total_score + LEAST(60, (array_length(matched_arr, 1) * 60 / array_length(skill_list, 1)));
    END IF;
  END IF;

  -- Title match score (0-40)
  FOREACH title IN ARRAY COALESCE(candidate_titles, '{}') LOOP
    IF title_lower LIKE '%' || LOWER(title) || '%' OR LOWER(title) LIKE '%' || title_lower || '%' THEN
      total_score := total_score + 40;
      EXIT;
    END IF;
  END LOOP;

  RETURN QUERY SELECT total_score, matched_arr, missing_arr;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recruiter_candidate_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidate_job_matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.resume_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scrape_runs ENABLE ROW LEVEL SECURITY;

-- Helper: get current user's role
CREATE OR REPLACE FUNCTION public.get_user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- PROFILES
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (id = auth.uid());

CREATE POLICY "Admin can view all profiles" ON public.profiles
  FOR SELECT USING (public.get_user_role() = 'admin');

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (id = auth.uid());

CREATE POLICY "Admin can manage all profiles" ON public.profiles
  FOR ALL USING (public.get_user_role() = 'admin');

-- CANDIDATES
CREATE POLICY "Admin full access candidates" ON public.candidates
  FOR ALL USING (public.get_user_role() = 'admin');

CREATE POLICY "Recruiters view assigned candidates" ON public.candidates
  FOR SELECT USING (
    public.get_user_role() = 'recruiter'
    AND id IN (
      SELECT candidate_id FROM public.recruiter_candidate_assignments
      WHERE recruiter_id = auth.uid()
    )
  );

CREATE POLICY "Candidates view own record" ON public.candidates
  FOR SELECT USING (user_id = auth.uid());

-- ASSIGNMENTS
CREATE POLICY "Admin manage assignments" ON public.recruiter_candidate_assignments
  FOR ALL USING (public.get_user_role() = 'admin');

CREATE POLICY "Recruiters view own assignments" ON public.recruiter_candidate_assignments
  FOR SELECT USING (recruiter_id = auth.uid());

-- JOBS
CREATE POLICY "Anyone authenticated can view active jobs" ON public.jobs
  FOR SELECT USING (auth.uid() IS NOT NULL AND is_active = TRUE);

CREATE POLICY "Admin manage jobs" ON public.jobs
  FOR ALL USING (public.get_user_role() = 'admin');

-- MATCHES
CREATE POLICY "Admin full access matches" ON public.candidate_job_matches
  FOR ALL USING (public.get_user_role() = 'admin');

CREATE POLICY "Recruiters view assigned candidate matches" ON public.candidate_job_matches
  FOR SELECT USING (
    public.get_user_role() = 'recruiter'
    AND candidate_id IN (
      SELECT candidate_id FROM public.recruiter_candidate_assignments
      WHERE recruiter_id = auth.uid()
    )
  );

-- RESUME VERSIONS
CREATE POLICY "Admin full access resumes" ON public.resume_versions
  FOR ALL USING (public.get_user_role() = 'admin');

CREATE POLICY "Recruiters manage assigned candidate resumes" ON public.resume_versions
  FOR ALL USING (
    public.get_user_role() = 'recruiter'
    AND candidate_id IN (
      SELECT candidate_id FROM public.recruiter_candidate_assignments
      WHERE recruiter_id = auth.uid()
    )
  );

-- APPLICATIONS
CREATE POLICY "Admin full access applications" ON public.applications
  FOR ALL USING (public.get_user_role() = 'admin');

CREATE POLICY "Recruiters manage assigned candidate apps" ON public.applications
  FOR ALL USING (
    public.get_user_role() = 'recruiter'
    AND candidate_id IN (
      SELECT candidate_id FROM public.recruiter_candidate_assignments
      WHERE recruiter_id = auth.uid()
    )
  );

CREATE POLICY "Candidates view own applications" ON public.applications
  FOR SELECT USING (
    candidate_id IN (
      SELECT id FROM public.candidates WHERE user_id = auth.uid()
    )
  );

-- SCRAPE RUNS
CREATE POLICY "Admin manage scrape runs" ON public.scrape_runs
  FOR ALL USING (public.get_user_role() = 'admin');

-- ============================================================================
-- STORAGE
-- ============================================================================

-- Create private bucket for resumes
INSERT INTO storage.buckets (id, name, public) VALUES ('resumes', 'resumes', FALSE)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Admin download resumes" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'resumes' AND public.get_user_role() = 'admin'
  );

CREATE POLICY "Recruiter download assigned resumes" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'resumes'
    AND public.get_user_role() = 'recruiter'
    AND (storage.foldername(name))[1] IN (
      SELECT candidate_id::TEXT FROM public.recruiter_candidate_assignments
      WHERE recruiter_id = auth.uid()
    )
  );

CREATE POLICY "Service role upload resumes" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'resumes');

CREATE POLICY "Service role delete resumes" ON storage.objects
  FOR DELETE USING (bucket_id = 'resumes');
